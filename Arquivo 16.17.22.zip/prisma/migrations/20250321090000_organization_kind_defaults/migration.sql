-- Organization kind and padel defaults on organizers
ALTER TABLE "app_v3"."organizers"
  ADD COLUMN IF NOT EXISTS "organization_kind" "app_v3"."OrganizationKind" NOT NULL DEFAULT 'PESSOA_SINGULAR',
  ADD COLUMN IF NOT EXISTS "padel_default_short_name" text,
  ADD COLUMN IF NOT EXISTS "padel_default_city" text,
  ADD COLUMN IF NOT EXISTS "padel_default_address" text,
  ADD COLUMN IF NOT EXISTS "padel_default_courts" integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS "padel_default_hours" text,
  ADD COLUMN IF NOT EXISTS "padel_default_rule_set_id" integer,
  ADD COLUMN IF NOT EXISTS "padel_favorite_categories" integer[] NOT NULL DEFAULT '{}';

ALTER TABLE "app_v3"."organizers"
  ADD CONSTRAINT "organizers_padel_default_rule_set_fk"
  FOREIGN KEY ("padel_default_rule_set_id") REFERENCES "app_v3"."padel_rule_sets"("id") ON DELETE SET NULL ON UPDATE NO ACTION;
