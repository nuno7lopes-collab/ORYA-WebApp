// prisma.config.ts
import 'dotenv/config';
import { defineConfig, env } from 'prisma/config';

export default defineConfig({
  schema: 'prisma/schema.prisma',
  migrations: {
    path: 'prisma/migrations',
  },
  datasource: {
    // aqui vive a DATABASE_URL para o CLI (generate, migrate, etc.)
    url: env('DATABASE_URL'),
  },
});