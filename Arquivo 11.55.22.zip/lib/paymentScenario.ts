export type PaymentScenario =
  | "SINGLE"
  | "GROUP_SPLIT"
  | "GROUP_FULL"
  | "RESALE"
  | "SUBSCRIPTION";

export function normalizePaymentScenario(raw: string | null | undefined): PaymentScenario {
  const value = (raw || "").toUpperCase();
  if (value === "GROUP_SPLIT") return "GROUP_SPLIT";
  if (value === "GROUP_FULL") return "GROUP_FULL";
  if (value === "RESALE") return "RESALE";
  if (value === "SUBSCRIPTION") return "SUBSCRIPTION";
  return "SINGLE";
}
