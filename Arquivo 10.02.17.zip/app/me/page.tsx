import Link from "next/link";
import { redirect } from "next/navigation";
import ProfileHeader from "@/app/components/profile/ProfileHeader";
import { createSupabaseServer } from "@/lib/supabaseServer";
import { prisma } from "@/lib/prisma";

type ServerTicket = {
  id: string;
  quantity: number;
  pricePaid: number;
  currency: string;
  purchasedAt: string;
  qrToken: string | null;
  event: {
    id: number;
    slug: string;
    title: string;
    startDate: string;
    locationName: string;
    coverImageUrl: string | null;
  };
  ticket: {
    id: string;
    name: string;
    description: string | null;
  };
};

function formatDateTime(value: string | Date | null | undefined) {
  if (!value) return "";
  const d = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(d.getTime())) return "";
  return new Intl.DateTimeFormat("pt-PT", {
    day: "2-digit",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
  }).format(d);
}

function formatMoney(valueCents: number | null | undefined) {
  if (!valueCents || Number.isNaN(valueCents)) return "0,00 €";
  const euros = valueCents / 100;
  return new Intl.NumberFormat("pt-PT", {
    style: "currency",
    currency: "EUR",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(euros);
}

async function loadUserAndProfile() {
  const supabase = await createSupabaseServer();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) return { user: null, profile: null };

  const profile = await prisma.profile.findUnique({
    where: { id: user.id },
  });

  return { user, profile };
}

async function loadTickets(userId: string): Promise<ServerTicket[]> {
  const userTickets = await prisma.ticket.findMany({
    where: { userId },
    orderBy: { purchasedAt: "desc" },
    include: {
      event: true,
      ticketType: true,
    },
    take: 6,
  });

  return userTickets
    .filter((t) => t.event && t.ticketType)
    .map((t) => ({
      id: t.id,
      quantity: 1,
      pricePaid: t.pricePaid ?? 0,
      currency: t.currency ?? "EUR",
      purchasedAt: t.purchasedAt.toISOString(),
      qrToken: t.qrSecret ?? null,
      event: {
        id: t.event!.id,
        slug: t.event!.slug,
        title: t.event!.title,
        startDate: t.event!.startsAt?.toISOString?.() ?? "",
        locationName: t.event!.locationName ?? "",
        coverImageUrl: t.event!.coverImageUrl ?? null,
      },
      ticket: {
        id: String(t.ticketType!.id),
        name: t.ticketType!.name ?? "Bilhete",
        description: t.ticketType!.description ?? null,
      },
    }));
}

export default async function MePage() {
  const { user, profile } = await loadUserAndProfile();

  if (!user) {
    redirect("/login");
  }

  const [tickets] = await Promise.all([loadTickets(user.id)]);

  const isAdmin = Array.isArray(profile?.roles) && profile!.roles.includes("admin");

  const totalEvents = tickets.length;
  const totalUpcoming = tickets.length; // simplificado sem distinção de data
  const totalPast = 0;
  const totalSpentEuros = formatMoney(
    tickets.reduce((sum, t) => sum + (t.pricePaid || 0), 0),
  );

  return (
    <main className="orya-body-bg text-white" aria-labelledby="me-page-title">
      <h1 id="me-page-title" className="sr-only">
        A minha conta
      </h1>

      <section className="max-w-5xl mx-auto px-5 py-8 md:py-10 space-y-6">
        <div className="min-h-[120px] rounded-3xl border border-white/10 bg-white/5 backdrop-blur-xl p-4 shadow-[0_24px_70px_rgba(0,0,0,0.85)]">
          <ProfileHeader
            isOwner
            name={profile?.fullName ?? null}
            username={profile?.username ?? null}
            avatarUrl={profile?.avatarUrl ?? null}
            createdAt={profile?.createdAt?.toISOString?.() ?? null}
          />
        </div>

        {/* STATS + BILHETES */}
        <div className="space-y-4">
          <div className="rounded-3xl border border-white/12 bg-gradient-to-br from-[#0f172a]/70 via-[#020617]/60 to-black/70 backdrop-blur-2xl p-6 shadow-[0_24px_70px_rgba(0,0,0,0.85)] min-h-[180px]">
            <div className="grid grid-cols-1 gap-3 text-[11px] md:grid-cols-4 md:gap-4">
              <div className="rounded-2xl border border-white/18 bg-white/[0.02] px-4 py-3">
                <p className="text-white/55">Eventos com bilhete</p>
                <p className="mt-1 text-lg font-semibold text-white">{totalEvents}</p>
                <p className="mt-0.5 text-[10px] text-white/50">Toda a tua timeline ORYA.</p>
              </div>
              <div className="rounded-2xl border border-emerald-400/40 bg-emerald-500/10 px-4 py-3">
                <p className="text-emerald-100/80">Próximos eventos</p>
                <p className="mt-1 text-lg font-semibold text-emerald-100">{totalUpcoming}</p>
                <p className="mt-0.5 text-[10px] text-emerald-100/80">O que ainda vem aí.</p>
              </div>
              <div className="rounded-2xl border border-white/18 bg-white/[0.02] px-4 py-3">
                <p className="text-white/55">Eventos já vividos</p>
                <p className="mt-1 text-lg font-semibold text-white">{totalPast}</p>
                <p className="mt-0.5 text-[10px] text-white/50">Memórias que já fazem parte.</p>
              </div>
              <div className="rounded-2xl border border-fuchsia-400/40 bg-fuchsia-500/10 px-4 py-3">
                <p className="text-fuchsia-100/85">Total investido</p>
                <p className="mt-1 text-lg font-semibold text-fuchsia-100">{totalSpentEuros}</p>
                <p className="mt-0.5 text-[10px] text-fuchsia-100/80">Em ser a pessoa que não fica em casa.</p>
              </div>
            </div>
          </div>

          <section className="rounded-2xl border border-[#6BFFFF]/30 bg-gradient-to-br from-[#020617f2] via-slate-950 to-slate-950 backdrop-blur-xl p-5 space-y-4 shadow-[0_16px_40px_rgba(15,23,42,0.7)] min-h-[260px]">
            <div className="flex items-center justify-between gap-3 flex-wrap">
              <div>
                <h2 className="text-sm font-semibold text-white/95">Os meus bilhetes</h2>
                <p className="text-[11px] text-white/65">
                  Tudo o que já reservaste na ORYA. Próximos eventos à frente, memórias logo atrás.
                </p>
              </div>
              <Link
                href="/me/tickets"
                className="inline-flex items-center gap-1 rounded-full bg-white text-black text-[11px] font-semibold px-3.5 py-1.5 shadow-[0_0_18px_rgba(255,255,255,0.3)] hover:scale-[1.02] active:scale-95 transition-transform"
              >
                Ver todos os bilhetes
                <span className="text-[12px]">↗</span>
              </Link>
            </div>

            {tickets.length === 0 && (
              <div className="rounded-3xl border border-white/10 bg-gradient-to-br from-[#0f172a]/70 via-[#020617]/60 to-black/70 backdrop-blur-2xl p-8 text-center flex flex-col items-center gap-4 shadow-[0_28px_80px_rgba(15,23,42,0.95)]">
                <div className="h-20 w-20 rounded-2xl bg-gradient-to-br from-[#FF00C8] via-[#6BFFFF] to-[#1646F5] flex items-center justify-center shadow-[0_0_35px_rgba(107,255,255,0.5)] text-black text-3xl font-bold">
                  🎟️
                </div>
                <h3 className="text-lg font-semibold text-white/95">Ainda não tens bilhetes ORYA</h3>
                <p className="text-[12px] text-white/70 max-w-sm">
                  Explora eventos, música, festas e experiências novas — e guarda os teus bilhetes com estilo.
                </p>
                <Link
                  href="/explorar"
                  className="inline-flex mt-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-[#FF00C8] via-[#6BFFFF] to-[#1646F5] text-xs font-semibold text-black shadow-[0_0_28px_rgba(107,255,255,0.5)] hover:scale-[1.05] active:scale-95 transition-transform"
                >
                  Explorar eventos
                </Link>
              </div>
            )}

            {tickets.length > 0 && (
              <div className="space-y-3">
                <p className="text-[11px] text-white/60">
                  Últimos bilhetes comprados. Em breve vais conseguir ver aqui a tua timeline completa de eventos.
                </p>
                <div className="flex gap-3 overflow-x-auto pb-1 pt-0.5">
                  {tickets.map((t) => (
                    <article
                      key={t.id}
                      className="group flex min-w-[260px] max-w-[280px] flex-col overflow-hidden rounded-2xl border border-white/15 bg-white/[0.03] backdrop-blur-xl shadow-[0_16px_45px_rgba(0,0,0,0.85)]"
                    >
                      <div className="relative h-32 w-full overflow-hidden">
                        {t.event.coverImageUrl ? (
                          // eslint-disable-next-line @next/next/no-img-element
                          <img
                            src={t.event.coverImageUrl}
                            alt={t.event.title}
                            className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-[1.03]"
                          />
                        ) : (
                          <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-[#FF00C8] via-[#6BFFFF] to-[#1646F5] text-[11px] font-semibold text-black/80">
                            Bilhete ORYA
                          </div>
                        )}
                        <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/85 via-black/30 to-transparent" />
                        <div className="absolute inset-x-3 bottom-2 space-y-0.5">
                          <p className="text-[10px] uppercase tracking-[0.16em] text-white/65">
                            Bilhete ORYA
                          </p>
                          <h3 className="text-sm font-semibold leading-snug line-clamp-2">
                            {t.event.title}
                          </h3>
                          <p className="text-[11px] text-white/80">
                            {formatDateTime(t.event.startDate)}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center justify-between gap-3 px-3 py-2.5 text-[11px]">
                        <div className="space-y-0.5">
                          <p className="text-white/65">
                            {t.quantity > 1 ? `${t.quantity} bilhetes` : "1 bilhete"}
                          </p>
                          <p className="text-white font-medium">{(t.pricePaid / 100).toFixed(2)} €</p>
                          <span className="inline-flex mt-0.5 items-center rounded-full bg-white/5 px-2 py-0.5 text-[10px] text-white/75">
                            {t.ticket.name}
                          </span>
                        </div>
                        <div className="flex items-center gap-3">
                          <img
                            src={`/api/qr/${t.qrToken ?? ""}`}
                            alt="QR Code do bilhete ORYA"
                            className="h-12 w-12 rounded-lg bg-black/20 p-1"
                          />
                          <div>
                            <p className="text-white">{t.event.title}</p>
                            <p className="text-xs text-white/60">{t.ticket.name}</p>
                          </div>
                        </div>
                      </div>
                    </article>
                  ))}
                </div>
              </div>
            )}
          </section>
        </div>

        {/* PERFIL / DETALHES */}
        <div className="grid grid-cols-1 gap-6">
          <section className="rounded-2xl border border-white/15 bg-gradient-to-br from-white/[0.04] via-slate-950/85 to-slate-950 backdrop-blur-xl p-5 space-y-4">
            <h2 className="text-sm font-semibold text-white/90">Detalhes da conta</h2>

            <div className="space-y-2 text-[11px] text-white/75">
              {!profile?.username && (
                <div className="mt-2 rounded-xl border border-amber-400/40 bg-amber-500/10 px-3 py-2 text-[11px] text-amber-100">
                  Ainda não escolheste um @username. Define um para ativares o teu perfil público.
                </div>
              )}

              {isAdmin && (
                <div className="flex items-center justify-between gap-3">
                  <span className="text-white/60">Área de staff</span>
                  <Link
                    href="/staff/eventos"
                    className="inline-flex items-center gap-1 rounded-full border border-white/20 px-3 py-1 text-white/80 hover:bg-white/10 transition-colors"
                  >
                    Entrar como staff
                  </Link>
                </div>
              )}

              <div className="flex items-center justify-between gap-3">
                <span className="text-white/60">Nome</span>
                <span className="font-medium text-white/85">
                  {profile?.fullName ?? "Ainda não definido"}
                </span>
              </div>

              <div className="flex items-center justify-between gap-3">
                <span className="text-white/60">Cidade</span>
                <span className="font-medium text-white/85">
                  {profile?.city ?? "Sem cidade definida"}
                </span>
              </div>
            </div>

            <p className="mt-3 text-[11px] text-white/55">
              Em breve vais poder escolher interesses, tipos de eventos favoritos e muito mais, para que a ORYA se adapte cada vez mais a ti.
            </p>
          </section>
        </div>
      </section>
    </main>
  );
}
