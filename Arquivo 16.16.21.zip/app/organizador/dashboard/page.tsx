"use client";

import DashboardClient from "../DashboardClient";

export default function OrganizerDashboardPage() {
  return <DashboardClient />;
}
