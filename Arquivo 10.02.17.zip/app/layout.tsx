import type { Metadata, Viewport } from "next";
import "./globals.css";
import { Navbar } from "./components/Navbar";
import { AuthModalProvider } from "./components/autenticação/AuthModalContext";
import AuthModal from "./components/autenticação/AuthModal";

// Use system font to avoid external fetch during build
const inter = { className: "font-sans" };

export const metadata: Metadata = {
  title: "ORYA",
  description: "O centro da tua vida social em Portugal.",
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="pt-PT" className="h-full" suppressHydrationWarning>
      <body
        className={`${inter.className} orya-body-bg antialiased min-h-screen flex flex-col`}
      >
        <AuthModalProvider>
          <Navbar />
          <main className="flex-1 pt-16 md:pt-20">
            {children}
          </main>
          <AuthModal />
        </AuthModalProvider>
      </body>
    </html>
  );
}
