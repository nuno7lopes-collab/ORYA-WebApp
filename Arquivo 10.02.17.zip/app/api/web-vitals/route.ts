import { NextResponse } from "next/server";

type WebVitalPayload = {
  id: string;
  name: string;
  label: string;
  value: number;
  navigationType?: number;
  url?: string;
  userAgent?: string;
  timestamp: number;
};

export async function POST(req: Request) {
  const payload = (await req.json().catch(() => null)) as WebVitalPayload | null;

  if (!payload || !payload.name || typeof payload.value !== "number") {
    return NextResponse.json({ ok: false, error: "invalid_payload" }, { status: 400 });
  }

  // Log to server console (Vercel functions) for quick inspection
  // eslint-disable-next-line no-console
  console.info("[WebVitals API]", payload);

  return NextResponse.json({ ok: true });
}
