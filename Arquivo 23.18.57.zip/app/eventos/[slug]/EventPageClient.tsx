"use client";

import { useCheckout } from "@/app/components/checkout/contextoCheckout";
import ModalCheckout from "@/app/components/checkout/ModalCheckout";
import Step1Bilhete from "@/app/components/checkout/Step1Bilhete";
import Step2Pagamento from "@/app/components/checkout/Step2Pagamento";
import Step3Sucesso from "@/app/components/checkout/Step3Sucesso";

type EventPageClientProps = {
  cover: string | null;
  event: any;
  uiTickets: any[];
  currentUserId: string | null;
};

export default function EventPageClient({
  cover,
  event,
  uiTickets,
  currentUserId,
}: EventPageClientProps) {
  const { isOpen, fecharCheckout, passo, irParaPasso } = useCheckout();

  return (
    <ModalCheckout />
  );
}