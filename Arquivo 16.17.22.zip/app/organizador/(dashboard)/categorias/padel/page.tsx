export const runtime = "nodejs";

import Link from "next/link";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { createSupabaseServer } from "@/lib/supabaseServer";
import { getActiveOrganizerForUser } from "@/lib/organizerContext";
import PadelTabsClient from "./PadelTabsClient";

const PAD_TAB_CLASS =
  "rounded-full border border-white/10 bg-white/5 px-3 py-1 text-[12px] text-white/75 hover:border-white/20";

export default async function PadelCategoryPage() {
  const supabase = await createSupabaseServer();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    redirect("/login?next=/organizador/categorias/padel");
  }

  const { organizer } = await getActiveOrganizerForUser(user.id);
  if (!organizer) {
    redirect("/organizador/organizations");
  }

  const recentPadelEvents = await prisma.event.findMany({
    where: {
      organizerId: organizer.id,
      templateType: "PADEL",
      isDeleted: false,
    },
    orderBy: { startsAt: "desc" },
    take: 5,
    select: {
      id: true,
      slug: true,
      title: true,
      startsAt: true,
      status: true,
    },
  });

  const [players, ruleSets, rankingEntries] = await Promise.all([
    prisma.padelPlayerProfile.findMany({
      where: { organizerId: organizer.id },
      orderBy: { createdAt: "desc" },
    }),
    prisma.padelRuleSet.findMany({
      where: { organizerId: organizer.id },
      orderBy: { createdAt: "desc" },
    }),
    prisma.padelRankingEntry.findMany({
      where: { organizerId: organizer.id },
      include: { player: true },
    }),
  ]);

  const rankingAggregated = Object.values(
    rankingEntries.reduce<Record<number, { player: any; points: number }>>((acc, row) => {
      if (!acc[row.playerId]) acc[row.playerId] = { player: row.player, points: 0 };
      acc[row.playerId].points += row.points;
      return acc;
    }, {}),
  ).sort((a, b) => b.points - a.points);

  return (
    <div className="orya-body-bg min-h-screen px-4 py-8 text-white md:px-8 lg:px-10">
      <div className="mx-auto max-w-6xl space-y-8">
        <header className="space-y-2">
          <p className="text-[11px] uppercase tracking-[0.2em] text-white/60">Categorias · Padel</p>
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="space-y-1">
              <h1 className="text-2xl font-semibold md:text-3xl">Padel · Gestão do clube</h1>
              <p className="text-white/70">
                Jogadores, rankings, formatos e regras base para todos os teus torneios.
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <Link
                href="/organizador/padel/torneios/novo"
                className="rounded-full bg-gradient-to-r from-[#FF00C8] via-[#6BFFFF] to-[#1646F5] px-4 py-2 text-sm font-semibold text-black shadow-[0_0_24px_rgba(107,255,255,0.35)] hover:scale-[1.02] transition"
              >
                Criar torneio PADEL
              </Link>
              <Link
                href="/organizador/eventos"
                className="rounded-full border border-white/20 px-4 py-2 text-sm text-white/80 hover:bg-white/10"
              >
                Ver eventos
              </Link>
            </div>
          </div>
        </header>

        <div className="grid gap-4 md:grid-cols-3">
          {[
            {
              title: "Jogadores & Níveis",
              desc: "Base de jogadores do clube, níveis e contacto.",
            },
            {
              title: "Rankings",
              desc: "Ranking local por categoria e época.",
            },
            {
              title: "Formatos & Regras",
              desc: "Formatos suportados e regras base do clube.",
            },
          ].map((card) => (
            <div
              key={card.title}
              className="rounded-2xl border border-white/10 bg-white/[0.04] p-4 shadow-[0_18px_50px_rgba(0,0,0,0.45)]"
            >
              <h3 className="text-lg font-semibold">{card.title}</h3>
              <p className="text-sm text-white/70">{card.desc}</p>
            </div>
          ))}
        </div>

        <div className="rounded-3xl border border-white/10 bg-black/40 px-4 py-4 shadow-[0_22px_70px_rgba(0,0,0,0.55)] md:px-6 md:py-5">
          <PadelTabsClient
            organizerId={organizer.id}
            initialPlayers={players}
            initialRuleSets={ruleSets}
            initialRankings={rankingAggregated.map((r, idx) => ({
              position: idx + 1,
              points: r.points,
              player: { id: r.player.id, fullName: r.player.fullName, level: r.player.level },
            }))}
          />
        </div>

        <div className="rounded-3xl border border-white/10 bg-white/[0.03] p-5 shadow-[0_18px_60px_rgba(0,0,0,0.5)]">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold">Torneios recentes</h3>
            <Link
              href="/organizador/eventos?type=PADEL"
              className="text-sm text-white/75 underline-offset-4 hover:text-white hover:underline"
            >
              Ver todos
            </Link>
          </div>
          <div className="mt-3 space-y-2">
            {recentPadelEvents.length === 0 && (
              <p className="text-sm text-white/60">Sem torneios de Padel ainda.</p>
            )}
            {recentPadelEvents.map((ev) => (
              <div
                key={ev.id}
                className="flex items-center justify-between rounded-xl border border-white/10 bg-black/40 px-4 py-3 text-sm"
              >
                <div>
                  <p className="font-semibold">{ev.title}</p>
                  <p className="text-white/60 text-[12px]">
                    {ev.startsAt?.toLocaleDateString("pt-PT")} · {ev.status}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <Link
                    href={`/organizador/eventos/${ev.id}`}
                    className="rounded-full border border-white/15 px-3 py-1 text-[12px] text-white/80 hover:bg-white/10"
                  >
                    Ver torneio
                  </Link>
                  <Link
                    href={`/eventos/${ev.slug}`}
                    className="rounded-full border border-white/15 px-3 py-1 text-[12px] text-white/70 hover:bg-white/10"
                  >
                    Página pública
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
