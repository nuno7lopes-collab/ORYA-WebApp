-- Padel MVP: modelos base + RLS alinhada por organizer_id/event_id

-- Enums
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'padel_format') THEN
    CREATE TYPE app_v3.padel_format AS ENUM (
      'TODOS_CONTRA_TODOS',
      'QUADRO_ELIMINATORIO',
      'GRUPOS_ELIMINATORIAS',
      'CAMPEONATO_LIGA',
      'QUADRO_AB',
      'NON_STOP'
    );
  END IF;

  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'padel_match_status') THEN
    CREATE TYPE app_v3.padel_match_status AS ENUM (
      'PENDING',
      'IN_PROGRESS',
      'DONE',
      'CANCELLED'
    );
  END IF;
END
$$;

-- Padel Player Profile
CREATE TABLE IF NOT EXISTS app_v3.padel_player_profiles (
  id            SERIAL PRIMARY KEY,
  organizer_id  INT         NOT NULL REFERENCES app_v3.organizers(id) ON DELETE CASCADE,
  user_id       UUID        NULL REFERENCES auth.users(id) ON DELETE SET NULL,
  full_name     TEXT        NOT NULL,
  email         CITEXT      NULL,
  phone         TEXT        NULL,
  gender        TEXT        NULL,
  level         TEXT        NULL,
  is_active     BOOLEAN     NOT NULL DEFAULT TRUE,
  notes         TEXT        NULL,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS padel_player_profiles_uniq_email
  ON app_v3.padel_player_profiles (organizer_id, email)
  WHERE email IS NOT NULL;

-- Padel Categories
CREATE TABLE IF NOT EXISTS app_v3.padel_categories (
  id                 SERIAL PRIMARY KEY,
  organizer_id       INT         NOT NULL REFERENCES app_v3.organizers(id) ON DELETE CASCADE,
  label              TEXT        NOT NULL,
  gender_restriction TEXT        NULL,
  min_level          TEXT        NULL,
  max_level          TEXT        NULL,
  is_default         BOOLEAN     NOT NULL DEFAULT FALSE,
  is_active          BOOLEAN     NOT NULL DEFAULT TRUE,
  season             TEXT        NULL,
  year               INT         NULL,
  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at         TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Padel Rule Sets
CREATE TABLE IF NOT EXISTS app_v3.padel_rule_sets (
  id              SERIAL PRIMARY KEY,
  organizer_id    INT         NOT NULL REFERENCES app_v3.organizers(id) ON DELETE CASCADE,
  name            TEXT        NOT NULL,
  tie_break_rules JSONB       NOT NULL DEFAULT '{}'::jsonb,
  points_table    JSONB       NOT NULL DEFAULT '{}'::jsonb,
  enabled_formats TEXT[]      NOT NULL DEFAULT ARRAY['TODOS_CONTRA_TODOS','QUADRO_ELIMINATORIO'],
  season          TEXT        NULL,
  year            INT         NULL,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Tournament config (1-1 com evento PADEL)
CREATE TABLE IF NOT EXISTS app_v3.padel_tournament_configs (
  id                  SERIAL PRIMARY KEY,
  event_id            INT         NOT NULL REFERENCES app_v3.events(id) ON DELETE CASCADE,
  organizer_id        INT         NOT NULL REFERENCES app_v3.organizers(id) ON DELETE CASCADE,
  format              app_v3.padel_format NOT NULL,
  number_of_courts    INT         NOT NULL DEFAULT 1,
  rule_set_id         INT         NULL REFERENCES app_v3.padel_rule_sets(id) ON DELETE SET NULL,
  default_category_id INT         NULL REFERENCES app_v3.padel_categories(id) ON DELETE SET NULL,
  enabled_formats     TEXT[]      NOT NULL DEFAULT ARRAY[]::text[],
  created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT padel_tournament_configs_event_unique UNIQUE (event_id)
);

-- Equipas
CREATE TABLE IF NOT EXISTS app_v3.padel_teams (
  id                 SERIAL PRIMARY KEY,
  event_id           INT         NOT NULL REFERENCES app_v3.events(id) ON DELETE CASCADE,
  category_id        INT         NULL REFERENCES app_v3.padel_categories(id) ON DELETE SET NULL,
  player1_id         INT         NULL REFERENCES app_v3.padel_player_profiles(id) ON DELETE SET NULL,
  player2_id         INT         NULL REFERENCES app_v3.padel_player_profiles(id) ON DELETE SET NULL,
  is_from_matchmaking BOOLEAN    NOT NULL DEFAULT FALSE,
  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at         TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Jogos
CREATE TABLE IF NOT EXISTS app_v3.padel_matches (
  id           SERIAL PRIMARY KEY,
  event_id     INT                  NOT NULL REFERENCES app_v3.events(id) ON DELETE CASCADE,
  category_id  INT                  NULL REFERENCES app_v3.padel_categories(id) ON DELETE SET NULL,
  court_number INT                  NULL,
  start_time   TIMESTAMPTZ          NULL,
  round_label  TEXT                 NULL,
  team_a_id    INT                  NULL REFERENCES app_v3.padel_teams(id) ON DELETE SET NULL,
  team_b_id    INT                  NULL REFERENCES app_v3.padel_teams(id) ON DELETE SET NULL,
  score        JSONB                NOT NULL DEFAULT '{}'::jsonb,
  status       app_v3.padel_match_status NOT NULL DEFAULT 'PENDING',
  created_at   TIMESTAMPTZ          NOT NULL DEFAULT now(),
  updated_at   TIMESTAMPTZ          NOT NULL DEFAULT now()
);

-- Ranking entries
CREATE TABLE IF NOT EXISTS app_v3.padel_ranking_entries (
  id           SERIAL PRIMARY KEY,
  organizer_id INT         NOT NULL REFERENCES app_v3.organizers(id) ON DELETE CASCADE,
  player_id    INT         NOT NULL REFERENCES app_v3.padel_player_profiles(id) ON DELETE CASCADE,
  event_id     INT         NOT NULL REFERENCES app_v3.events(id) ON DELETE CASCADE,
  points       INT         NOT NULL DEFAULT 0,
  position     INT         NULL,
  level        TEXT        NULL,
  season       TEXT        NULL,
  year         INT         NULL,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- RLS helpers (policies per table)
ALTER TABLE app_v3.padel_player_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE app_v3.padel_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE app_v3.padel_rule_sets ENABLE ROW LEVEL SECURITY;
ALTER TABLE app_v3.padel_tournament_configs ENABLE ROW LEVEL SECURITY;
ALTER TABLE app_v3.padel_teams ENABLE ROW LEVEL SECURITY;
ALTER TABLE app_v3.padel_matches ENABLE ROW LEVEL SECURITY;
ALTER TABLE app_v3.padel_ranking_entries ENABLE ROW LEVEL SECURITY;

-- Policy helper: membership or owner for organizer-scoped tables
CREATE POLICY padel_player_profiles_rw ON app_v3.padel_player_profiles
  FOR ALL
  USING (
    auth.uid() IS NOT NULL AND
    EXISTS (
      SELECT 1
      FROM app_v3.organizers o
      WHERE o.id = organizer_id
        AND (
          o.user_id = auth.uid()
          OR EXISTS (
            SELECT 1 FROM app_v3.organizer_members m
            WHERE m.organizer_id = o.id AND m.user_id = auth.uid()
          )
        )
    )
  )
  WITH CHECK (
    auth.uid() IS NOT NULL AND
    EXISTS (
      SELECT 1
      FROM app_v3.organizers o
      WHERE o.id = organizer_id
        AND (
          o.user_id = auth.uid()
          OR EXISTS (
            SELECT 1 FROM app_v3.organizer_members m
            WHERE m.organizer_id = o.id AND m.user_id = auth.uid()
          )
        )
    )
  );

CREATE POLICY padel_categories_rw ON app_v3.padel_categories
  FOR ALL
  USING (
    auth.uid() IS NOT NULL AND
    EXISTS (
      SELECT 1
      FROM app_v3.organizers o
      WHERE o.id = organizer_id
        AND (
          o.user_id = auth.uid()
          OR EXISTS (
            SELECT 1 FROM app_v3.organizer_members m
            WHERE m.organizer_id = o.id AND m.user_id = auth.uid()
          )
        )
    )
  )
  WITH CHECK (
    auth.uid() IS NOT NULL AND
    EXISTS (
      SELECT 1
      FROM app_v3.organizers o
      WHERE o.id = organizer_id
        AND (
          o.user_id = auth.uid()
          OR EXISTS (
            SELECT 1 FROM app_v3.organizer_members m
            WHERE m.organizer_id = o.id AND m.user_id = auth.uid()
          )
        )
    )
  );

CREATE POLICY padel_rule_sets_rw ON app_v3.padel_rule_sets
  FOR ALL
  USING (
    auth.uid() IS NOT NULL AND
    EXISTS (
      SELECT 1
      FROM app_v3.organizers o
      WHERE o.id = organizer_id
        AND (
          o.user_id = auth.uid()
          OR EXISTS (
            SELECT 1 FROM app_v3.organizer_members m
            WHERE m.organizer_id = o.id AND m.user_id = auth.uid()
          )
        )
    )
  )
  WITH CHECK (
    auth.uid() IS NOT NULL AND
    EXISTS (
      SELECT 1
      FROM app_v3.organizers o
      WHERE o.id = organizer_id
        AND (
          o.user_id = auth.uid()
          OR EXISTS (
            SELECT 1 FROM app_v3.organizer_members m
            WHERE m.organizer_id = o.id AND m.user_id = auth.uid()
          )
        )
    )
  );

CREATE POLICY padel_ranking_entries_rw ON app_v3.padel_ranking_entries
  FOR ALL
  USING (
    auth.uid() IS NOT NULL AND
    EXISTS (
      SELECT 1
      FROM app_v3.organizers o
      WHERE o.id = organizer_id
        AND (
          o.user_id = auth.uid()
          OR EXISTS (
            SELECT 1 FROM app_v3.organizer_members m
            WHERE m.organizer_id = o.id AND m.user_id = auth.uid()
          )
        )
    )
  )
  WITH CHECK (
    auth.uid() IS NOT NULL AND
    EXISTS (
      SELECT 1
      FROM app_v3.organizers o
      WHERE o.id = organizer_id
        AND (
          o.user_id = auth.uid()
          OR EXISTS (
            SELECT 1 FROM app_v3.organizer_members m
            WHERE m.organizer_id = o.id AND m.user_id = auth.uid()
          )
        )
    )
  );

-- Policies for event-scoped tables (via events.organizer_id)
CREATE POLICY padel_tournament_configs_rw ON app_v3.padel_tournament_configs
  FOR ALL
  USING (
    auth.uid() IS NOT NULL AND
    EXISTS (
      SELECT 1
      FROM app_v3.events e
      JOIN app_v3.organizers o ON o.id = e.organizer_id
      WHERE e.id = event_id
        AND (
          o.user_id = auth.uid()
          OR EXISTS (
            SELECT 1 FROM app_v3.organizer_members m
            WHERE m.organizer_id = o.id AND m.user_id = auth.uid()
          )
        )
    )
  )
  WITH CHECK (
    auth.uid() IS NOT NULL AND
    EXISTS (
      SELECT 1
      FROM app_v3.events e
      JOIN app_v3.organizers o ON o.id = e.organizer_id
      WHERE e.id = event_id
        AND (
          o.user_id = auth.uid()
          OR EXISTS (
            SELECT 1 FROM app_v3.organizer_members m
            WHERE m.organizer_id = o.id AND m.user_id = auth.uid()
          )
        )
    )
  );

CREATE POLICY padel_teams_rw ON app_v3.padel_teams
  FOR ALL
  USING (
    auth.uid() IS NOT NULL AND
    EXISTS (
      SELECT 1
      FROM app_v3.events e
      JOIN app_v3.organizers o ON o.id = e.organizer_id
      WHERE e.id = event_id
        AND (
          o.user_id = auth.uid()
          OR EXISTS (
            SELECT 1 FROM app_v3.organizer_members m
            WHERE m.organizer_id = o.id AND m.user_id = auth.uid()
          )
        )
    )
  )
  WITH CHECK (
    auth.uid() IS NOT NULL AND
    EXISTS (
      SELECT 1
      FROM app_v3.events e
      JOIN app_v3.organizers o ON o.id = e.organizer_id
      WHERE e.id = event_id
        AND (
          o.user_id = auth.uid()
          OR EXISTS (
            SELECT 1 FROM app_v3.organizer_members m
            WHERE m.organizer_id = o.id AND m.user_id = auth.uid()
          )
        )
    )
  );

CREATE POLICY padel_matches_rw ON app_v3.padel_matches
  FOR ALL
  USING (
    auth.uid() IS NOT NULL AND
    EXISTS (
      SELECT 1
      FROM app_v3.events e
      JOIN app_v3.organizers o ON o.id = e.organizer_id
      WHERE e.id = event_id
        AND (
          o.user_id = auth.uid()
          OR EXISTS (
            SELECT 1 FROM app_v3.organizer_members m
            WHERE m.organizer_id = o.id AND m.user_id = auth.uid()
          )
        )
    )
  )
  WITH CHECK (
    auth.uid() IS NOT NULL AND
    EXISTS (
      SELECT 1
      FROM app_v3.events e
      JOIN app_v3.organizers o ON o.id = e.organizer_id
      WHERE e.id = event_id
        AND (
          o.user_id = auth.uid()
          OR EXISTS (
            SELECT 1 FROM app_v3.organizer_members m
            WHERE m.organizer_id = o.id AND m.user_id = auth.uid()
          )
        )
    )
  );
