"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";

type OrganizerDefaults = {
  organizationKind: string | null;
  padelDefaults?: {
    shortName?: string | null;
    city?: string | null;
    address?: string | null;
    courts?: number;
    hours?: string | null;
    favoriteCategories?: number[];
    ruleSetId?: number | null;
  } | null;
  city?: string | null;
  displayName?: string | null;
};

type PadelCategory = { id: number; name: string; level?: string | null };

type TicketRow = {
  name: string;
  categoryId: number | null;
  price: string;
  capacity: string;
};

function formatDateSuggestion() {
  const now = new Date();
  const nextSaturday = new Date(now);
  nextSaturday.setDate(now.getDate() + ((6 - now.getDay() + 7) % 7 || 7));
  nextSaturday.setHours(10, 0, 0, 0);
  const start = nextSaturday.toISOString().slice(0, 16);
  const endDate = new Date(nextSaturday);
  endDate.setHours(18, 0, 0, 0);
  const end = endDate.toISOString().slice(0, 16);
  return { start, end };
}

export default function PadelWizardSimple() {
  const router = useRouter();
  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [loadingDefaults, setLoadingDefaults] = useState(true);
  const [defaults, setDefaults] = useState<OrganizerDefaults | null>(null);
  const [categories, setCategories] = useState<PadelCategory[]>([]);

  const [title, setTitle] = useState("");
  const [startsAt, setStartsAt] = useState("");
  const [endsAt, setEndsAt] = useState("");
  const [city, setCity] = useState("");
  const [club, setClub] = useState("");
  const [address, setAddress] = useState("");
  const [coverUrl, setCoverUrl] = useState<string | null>(null);
  const [uploadingCover, setUploadingCover] = useState(false);
  const [visibility, setVisibility] = useState<"PUBLIC" | "PRIVATE">("PUBLIC");
  const [listed, setListed] = useState(true);

  const [tickets, setTickets] = useState<TicketRow[]>([
    { name: "", categoryId: null, price: "", capacity: "" },
  ]);

  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  // Load organizer defaults + categories
  useEffect(() => {
    let cancelled = false;
    async function load() {
      try {
        const [orgRes, catRes] = await Promise.all([
          fetch("/api/organizador/me"),
          fetch("/api/padel/categories/my"),
        ]);
        const orgJson = await orgRes.json().catch(() => null);
        const catJson = await catRes.json().catch(() => null);
        if (!cancelled) {
          if (orgRes.ok && orgJson?.organizer) {
            const org = orgJson.organizer as OrganizerDefaults;
            setDefaults(org);
            const padel = org.padelDefaults;
            setCity(padel?.city || org.city || "");
            setClub(padel?.shortName || org.displayName || "");
            setAddress(padel?.address || "");
          }
          if (catRes.ok && Array.isArray(catJson?.items)) {
            setCategories(catJson.items as PadelCategory[]);
          }
        }
      } catch (err) {
        console.warn("[PadelWizard] defaults load failed", err);
      } finally {
        if (!cancelled) setLoadingDefaults(false);
      }
    }
    load();
    return () => {
      cancelled = true;
    };
  }, []);

  const handleUploadCover = async (file: File | null) => {
    if (!file) return;
    setUploadingCover(true);
    setError(null);
    try {
      const formData = new FormData();
      formData.append("file", file);
      const uploadRes = await fetch("/api/upload", { method: "POST", body: formData });
      const uploadJson = await uploadRes.json().catch(() => null);
      if (!uploadRes.ok || !uploadJson?.url) throw new Error(uploadJson?.error || "Falha no upload da imagem.");
      setCoverUrl(uploadJson.url as string);
    } catch (err) {
      console.error("[PadelWizard] upload cover", err);
      setError("Não foi possível carregar a imagem de capa.");
    } finally {
      setUploadingCover(false);
    }
  };

  // Quick fill
  const handleQuickFill = () => {
    const { start, end } = formatDateSuggestion();
    setTitle((prev) => prev || `Open ${defaults?.padelDefaults?.shortName || defaults?.displayName || "Padel"}`);
    setStartsAt(start);
    setEndsAt(end);
    const suggestedCat =
      (defaults?.padelDefaults?.favoriteCategories?.[0] &&
        categories.find((c) => c.id === defaults?.padelDefaults?.favoriteCategories?.[0])) ||
      categories[0];
    setTickets([
      {
        name: suggestedCat ? `Dupla ${suggestedCat.name}` : "Dupla Masculina 4/5",
        categoryId: suggestedCat?.id ?? null,
        price: "40",
        capacity: "16",
      },
    ]);
  };

  const addTicket = () => {
    setTickets((prev) => [...prev, { name: "", categoryId: null, price: "", capacity: "" }]);
  };
  const updateTicket = (idx: number, field: keyof TicketRow, value: string | number | null) => {
    setTickets((prev) =>
      prev.map((t, i) => (i === idx ? { ...t, [field]: value as any } : t)),
    );
  };
  const removeTicket = (idx: number) => {
    setTickets((prev) => prev.filter((_, i) => i !== idx));
  };

  const canNext = useMemo(() => {
    if (step === 1) return Boolean(title.trim() && startsAt && city);
    if (step === 2) return tickets.some((t) => t.name.trim() && t.price);
    return true;
  }, [step, title, startsAt, city, tickets]);

  const grossEstimate = useMemo(() => {
    return tickets.reduce((acc, t) => {
      const price = Number(t.price.replace(",", ".")) || 0;
      const cap = Number(t.capacity) || 0;
      return acc + price * cap;
    }, 0);
  }, [tickets]);

  const handleSubmit = async () => {
    setSubmitting(true);
    setError(null);
    try {
      const defaultRuleSetId = defaults?.padelDefaults?.ruleSetId ?? null;
      const payload = {
        title: title.trim(),
        startsAt,
        endsAt: endsAt || startsAt,
        locationCity: city.trim(),
        locationName: club.trim(),
        address: address.trim() || null,
        coverImageUrl: coverUrl,
        templateType: "PADEL",
        categories: ["DESPORTO"],
        feeMode: "ON_TOP",
        publicListingEnabled: listed,
        visibility,
        ticketTypes: tickets
          .filter((t) => t.name.trim())
          .map((t) => ({
            name: t.name.trim(),
            price: Number(t.price.replace(",", ".")) || 0,
            totalQuantity: t.capacity ? Number(t.capacity) : null,
          })),
        padel: {
          padelV2Enabled: true,
          ruleSetId: defaultRuleSetId,
        },
      };

      const res = await fetch("/api/organizador/padel/tournaments/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const json = await res.json().catch(() => null);
      if (!res.ok || !json?.ok) {
        throw new Error(json?.error || "Erro ao criar torneio.");
      }
      if (json.event?.id) router.push(`/organizador/eventos/${json.event.id}`);
      else if (json.event?.slug) router.push(`/eventos/${json.event.slug}`);
      else router.push("/organizador/eventos");
    } catch (err) {
      console.error(err);
      setError(err instanceof Error ? err.message : "Erro ao criar torneio.");
    } finally {
      setSubmitting(false);
    }
  };

  const canEditPadelSimple = defaults?.organizationKind === "CLUBE_PADEL" || !defaults;

  return (
    <div className="mx-auto flex max-w-6xl flex-col gap-6 px-4 py-8 text-white md:flex-row md:items-start md:px-8">
      <div className="flex-1 space-y-4">
        <header className="space-y-1">
          <p className="text-[11px] uppercase tracking-[0.26em] text-white/55">Padel · Criar torneio</p>
          <div className="flex flex-wrap items-center gap-2">
            <h1 className="text-2xl font-semibold tracking-tight">Wizard rápido para clubes</h1>
            <button
              type="button"
              onClick={handleQuickFill}
              className="rounded-full border border-white/20 px-3 py-1 text-[12px] text-white/80 hover:bg-white/10"
            >
              Criar torneio rápido
            </button>
          </div>
          <p className="text-sm text-white/65">3 passos: Básico → Categorias → Rever & criar. FULL/SPLIT geridos pela plataforma.</p>
        </header>

        <div className="flex items-center gap-2 text-[12px]">
          {[1, 2, 3].map((s) => (
            <button
              key={s}
              type="button"
              onClick={() => setStep(s as 1 | 2 | 3)}
              className={`rounded-full px-3 py-1 border border-white/15 ${
                step === s ? "bg-white text-black font-semibold" : "bg-black/40 text-white/70"
              }`}
            >
              {s === 1 ? "1. Básico" : s === 2 ? "2. Categorias" : "3. Rever"}
            </button>
          ))}
        </div>

        {error && (
          <div className="rounded-md border border-red-500/40 bg-red-500/10 px-4 py-3 text-sm text-red-100">
            {error}
          </div>
        )}

        {step === 1 && (
          <div className="space-y-3 rounded-2xl border border-white/10 bg-black/35 p-4 shadow-[0_20px_60px_rgba(0,0,0,0.55)]">
            <div className="space-y-1">
              <label className="text-sm">Imagem de capa</label>
              <div className="flex flex-wrap items-center gap-3">
                <div className="h-24 w-36 overflow-hidden rounded-xl border border-white/15 bg-black/30 text-[11px] text-white/60 flex items-center justify-center">
                  {coverUrl ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img src={coverUrl} alt="Capa" className="h-full w-full object-cover" />
                  ) : (
                    "Sem imagem"
                  )}
                </div>
                <label className="inline-flex cursor-pointer items-center gap-2 rounded-full border border-white/20 px-3 py-1 text-[12px] text-white/80 hover:bg-white/10">
                  <span>{coverUrl ? "Substituir" : "Carregar imagem"}</span>
                  <input type="file" className="hidden" accept="image/*" onChange={(e) => handleUploadCover(e.target.files?.[0] ?? null)} />
                </label>
                {coverUrl && (
                  <button type="button" onClick={() => setCoverUrl(null)} className="text-[12px] text-white/70 underline">
                    Remover
                  </button>
                )}
                {uploadingCover && <span className="text-[11px] text-white/60">A carregar…</span>}
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-sm">Título *</label>
              <input
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full rounded-lg border border-white/15 bg-black/30 px-3 py-2 text-sm outline-none"
                placeholder="Open do Clube"
              />
            </div>
            <div className="grid gap-3 md:grid-cols-2">
              <label className="space-y-1 text-sm">
                Início *
                <input
                  type="datetime-local"
                  value={startsAt}
                  onChange={(e) => setStartsAt(e.target.value)}
                  className="w-full rounded-lg border border-white/15 bg-black/30 px-3 py-2 text-sm outline-none"
                />
              </label>
              <label className="space-y-1 text-sm">
                Fim
                <input
                  type="datetime-local"
                  value={endsAt}
                  onChange={(e) => setEndsAt(e.target.value)}
                  className="w-full rounded-lg border border-white/15 bg-black/30 px-3 py-2 text-sm outline-none"
                />
              </label>
            </div>
            <div className="grid gap-3 md:grid-cols-2">
              <label className="space-y-1 text-sm">
                Clube / nome curto
                <input
                  value={club}
                  onChange={(e) => setClub(e.target.value)}
                  className="w-full rounded-lg border border-white/15 bg-black/30 px-3 py-2 text-sm outline-none"
                  placeholder="Clube XPTO"
                />
              </label>
              <label className="space-y-1 text-sm">
                Cidade *
                <input
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  className="w-full rounded-lg border border-white/15 bg-black/30 px-3 py-2 text-sm outline-none"
                  placeholder="Porto, Lisboa…"
                />
              </label>
            </div>
            <label className="space-y-1 text-sm">
              Morada
              <input
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                className="w-full rounded-lg border border-white/15 bg-black/30 px-3 py-2 text-sm outline-none"
                placeholder="Rua e número"
              />
            </label>
            <div className="grid gap-3 md:grid-cols-2">
              <label className="space-y-1 text-sm">
                Visibilidade
                <select
                  value={visibility}
                  onChange={(e) => setVisibility(e.target.value as "PUBLIC" | "PRIVATE")}
                  className="w-full rounded-lg border border-white/15 bg-black/30 px-3 py-2 text-sm outline-none"
                >
                  <option value="PUBLIC">Público</option>
                  <option value="PRIVATE">Privado</option>
                </select>
              </label>
              <label className="space-y-1 text-sm">
                Listagem
                <select
                  value={listed ? "yes" : "no"}
                  onChange={(e) => setListed(e.target.value === "yes")}
                  className="w-full rounded-lg border border-white/15 bg-black/30 px-3 py-2 text-sm outline-none"
                >
                  <option value="yes">Listar na página da organização</option>
                  <option value="no">Não listar</option>
                </select>
              </label>
            </div>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-3 rounded-2xl border border-white/10 bg-black/35 p-4 shadow-[0_20px_60px_rgba(0,0,0,0.55)]">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-sm font-semibold">Categorias & preço</h2>
                <p className="text-[11px] text-white/60">Preço por dupla (a plataforma divide por jogador automaticamente).</p>
              </div>
              <button
                type="button"
                onClick={addTicket}
                className="rounded-full border border-white/20 px-3 py-1 text-[12px] text-white/80 hover:bg-white/10"
              >
                + Adicionar categoria
              </button>
            </div>
            {tickets.map((t, idx) => (
              <div key={idx} className="space-y-2 rounded-xl border border-white/10 bg-black/30 p-3">
                <div className="flex items-center gap-2">
                  <input
                    value={t.name}
                    onChange={(e) => updateTicket(idx, "name", e.target.value)}
                    placeholder="Nome (ex.: Dupla Masc 4/5)"
                    className="flex-1 rounded-lg border border-white/15 bg-black/30 px-3 py-2 text-sm outline-none"
                  />
                  <button onClick={() => removeTicket(idx)} type="button" className="text-[11px] text-red-300">
                    Remover
                  </button>
                </div>
                <div className="grid gap-2 md:grid-cols-3">
                  <select
                    value={t.categoryId ?? ""}
                    onChange={(e) => updateTicket(idx, "categoryId", e.target.value ? Number(e.target.value) : null)}
                    className="rounded-lg border border-white/15 bg-black/30 px-3 py-2 text-sm outline-none"
                  >
                    <option value="">Categoria Padel</option>
                    {categories.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name}
                        {c.level ? ` · ${c.level}` : ""}
                      </option>
                    ))}
                  </select>
                  <input
                    type="number"
                    min={0}
                    value={t.price}
                    onChange={(e) => updateTicket(idx, "price", e.target.value)}
                    placeholder="Preço por dupla (€)"
                    className="rounded-lg border border-white/15 bg-black/30 px-3 py-2 text-sm outline-none"
                  />
                  <input
                    type="number"
                    min={0}
                    value={t.capacity}
                    onChange={(e) => updateTicket(idx, "capacity", e.target.value)}
                    placeholder="Nº de duplas"
                    className="rounded-lg border border-white/15 bg-black/30 px-3 py-2 text-sm outline-none"
                  />
                </div>
              </div>
            ))}
            <p className="text-[11px] text-white/55">
              Vagas = nº máximo de duplas nesta categoria. FULL + SPLIT e convites são geridos pela plataforma.
            </p>
          </div>
        )}

        {step === 3 && (
          <div className="space-y-3 rounded-2xl border border-white/10 bg-black/35 p-4 shadow-[0_20px_60px_rgba(0,0,0,0.55)]">
            <h2 className="text-sm font-semibold uppercase tracking-[0.2em] text-white/70">Revisão</h2>
          <div className="space-y-2 text-sm text-white/80">
            <p><strong>Título:</strong> {title || "—"}</p>
            <p><strong>Quando:</strong> {startsAt || "—"} → {endsAt || "—"}</p>
            <p><strong>Onde:</strong> {club || "—"}, {city || "—"}</p>
            <p><strong>Listagem:</strong> {visibility === "PUBLIC" ? "Público" : "Privado"} · {listed ? "Listado" : "Não listado"}</p>
            <p><strong>Categorias:</strong> {tickets.length} linha(s)</p>
            <p><strong>Estimativa bruta:</strong> {grossEstimate.toFixed(2)} €</p>
            <p className="text-[11px] text-white/60">
              Courts padrão: {defaults?.padelDefaults?.courts ?? 1} · Horário típico: {defaults?.padelDefaults?.hours || "—"}
            </p>
          </div>
          </div>
        )}

        <div className="flex flex-wrap gap-2">
          <button
            type="button"
            onClick={() => setStep((s) => (s > 1 ? ((s - 1) as 1 | 2 | 3) : s))}
            className="rounded-full border border-white/20 px-4 py-2 text-sm text-white/80 hover:bg-white/10"
          >
            Anterior
          </button>
          {step < 3 ? (
            <button
              type="button"
              disabled={!canNext}
              onClick={() => setStep((s) => (s < 3 ? ((s + 1) as 1 | 2 | 3) : s))}
              className="rounded-full border border-white/20 px-4 py-2 text-sm text-white hover:bg-white/10 disabled:opacity-40"
            >
              Seguinte
            </button>
          ) : (
            <button
              type="button"
              disabled={submitting}
              onClick={handleSubmit}
              className="rounded-full bg-gradient-to-r from-[#FF00C8] via-[#6BFFFF] to-[#1646F5] px-5 py-2 text-sm font-semibold text-black shadow hover:scale-[1.01] disabled:opacity-60"
            >
              {submitting ? "A criar…" : "Criar torneio de Padel"}
            </button>
          )}
        </div>
      </div>

      {/* Preview */}
      <aside className="sticky top-6 w-full max-w-sm rounded-3xl border border-white/10 bg-white/[0.04] p-4 shadow-[0_24px_60px_rgba(0,0,0,0.55)] md:w-80">
        <p className="text-[11px] uppercase tracking-[0.24em] text-white/60">Pré-visualização</p>
        <div className="mt-3 space-y-3">
          <div className="h-36 w-full overflow-hidden rounded-2xl border border-white/10 bg-black/30 text-[11px] text-white/60 flex items-center justify-center">
            {coverUrl ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={coverUrl} alt="Capa" className="h-full w-full object-cover" />
            ) : (
              "Sem imagem"
            )}
          </div>
          <div>
            <h3 className="text-lg font-semibold">{title || "Torneio sem título"}</h3>
            <p className="text-sm text-white/65">
              {city || "Cidade"} · {startsAt || "Data a definir"}
            </p>
          </div>
          <div className="space-y-1 rounded-2xl border border-white/10 bg-black/25 p-3 text-sm">
            <p className="text-[11px] uppercase tracking-[0.14em] text-white/60">Categorias & preço</p>
            {tickets.map((t, i) => (
              <div key={`${t.name}-${i}`} className="flex items-center justify-between text-white/80">
                <span>{t.name || "Sem nome"}</span>
                <span className="text-white">{t.price ? `${Number(t.price || 0).toFixed(2)} €` : "—"}</span>
              </div>
            ))}
            {tickets.length === 0 && <p className="text-[12px] text-white/55">Adiciona pelo menos uma categoria.</p>}
          </div>
          <div className="rounded-2xl border border-white/10 bg-black/30 p-3 text-sm">
            <div className="flex items-center justify-between text-white/80">
              <span>Receita bruta estimada</span>
              <span className="text-base font-semibold">{grossEstimate.toFixed(2)} €</span>
            </div>
            <p className="text-[11px] text-white/55">Preço × vagas. FULL/SPLIT e fees tratados pela plataforma.</p>
          </div>
        </div>
      </aside>
    </div>
  );
}
