"use client";

import { useState, useEffect, useRef } from "react";
import { useRouter } from "next/navigation";
import { useAuthModal } from "./AuthModalContext";
import { supabaseBrowser } from "@/lib/supabaseBrowser";

type Mode = "login" | "signup" | "verify" | "onboarding";

export default function AuthModal() {
  const {
    isOpen,
    mode,
    email,
    setEmail,
    closeModal,
    setMode,
    redirectTo,
  } = useAuthModal();

  const router = useRouter();

  const [password, setPassword] = useState("");
  const [otp, setOtp] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [fullName, setFullName] = useState("");
  const [username, setUsername] = useState("");

  const modalRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    setError(null);
    setPassword("");
    setOtp("");
    if (mode !== "onboarding") {
      setFullName("");
      setUsername("");
    }
  }, [mode, isOpen]);

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (modalRef.current && !modalRef.current.contains(e.target as Node)) {
        closeModal();
      }
    }
    if (isOpen) {
      document.addEventListener("mousedown", handleClickOutside);
    }
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [isOpen, closeModal]);

  if (!isOpen) return null;

  async function finishAuthAndMaybeOnboard() {
    try {
      const res = await fetch("/api/auth/me", {
        method: "GET",
        credentials: "include",
      });

      if (!res.ok) {
        // Se não conseguir ler, pelo menos fecha o modal
        closeModal();
        if (redirectTo) router.push(redirectTo);
        return;
      }

      const data = await res.json();
      const onboardingDone = data?.profile?.onboardingDone;

      if (onboardingDone) {
        closeModal();
        if (redirectTo) router.push(redirectTo);
      } else {
        setMode("onboarding");
      }
    } catch (err) {
      console.error("finishAuthAndMaybeOnboard error", err);
      closeModal();
      if (redirectTo) router.push(redirectTo);
    }
  }

  async function handleLogin() {
    setError(null);
    setLoading(true);

    const emailToUse = (email || "").trim().toLowerCase();

    if (!emailToUse || !password) {
      setError("Preenche o email e a password.");
      setLoading(false);
      return;
    }

    const { data, error } = await supabaseBrowser.auth.signInWithPassword({
      email: emailToUse,
      password,
    });

    if (error) {
      setError(error.message);
      setLoading(false);
      return;
    }

    await finishAuthAndMaybeOnboard();
    setLoading(false);
  }

  async function handleSignup() {
    setError(null);
    setLoading(true);

    const emailToUse = (email || "").trim().toLowerCase();

    if (!emailToUse || !password) {
      setError("Preenche o email e a password.");
      setLoading(false);
      return;
    }

    const { data, error } = await supabaseBrowser.auth.signUp({
      email: emailToUse,
      password,
    });

    if (error) {
      setError(error.message);
      setLoading(false);
      return;
    }

    setMode("verify");
    setLoading(false);
  }

  async function handleVerify() {
    setError(null);
    setLoading(true);

    const emailToUse = (email || "").trim().toLowerCase();

    if (!emailToUse) {
      setError("Email em falta. Volta atrás e inicia sessão novamente.");
      setLoading(false);
      return;
    }

    if (!otp || otp.trim().length < 6) {
      setError("Introduce o código completo.");
      setLoading(false);
      return;
    }

    const { data, error } = await supabaseBrowser.auth.verifyOtp({
      type: "email",
      email: emailToUse,
      token: otp.trim(),
    });

    if (error) {
      setError(error.message);
      setLoading(false);
      return;
    }

    await finishAuthAndMaybeOnboard();
    setLoading(false);
  }

  async function handleOnboardingSave() {
    setError(null);
    setLoading(true);

    try {
      const res = await fetch("/api/profiles/save-basic", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          fullName: fullName.trim() || null,
          username: username.trim(),
        }),
      });

      const data = await res.json().catch(() => null);

      if (!res.ok || (data && data.ok === false)) {
        const msg = data?.error || "Não foi possível guardar o perfil.";
        setError(msg);
        setLoading(false);
        return;
      }

      // Depois de onboarding concluído, fechamos modal e fazemos redirect se existir
      closeModal();
      if (redirectTo) router.push(redirectTo);
      setLoading(false);
    } catch (err) {
      console.error("handleOnboardingSave error", err);
      setError("Ocorreu um erro ao guardar o perfil.");
      setLoading(false);
    }
  }

  const title =
    mode === "login"
      ? "Iniciar sessão"
      : mode === "signup"
      ? "Criar conta"
      : mode === "verify"
      ? "Confirmar email"
      : "Completar perfil";

  const isPrimaryDisabled =
    loading ||
    ((mode === "login" || mode === "signup") && (!email || !password)) ||
    (mode === "verify" && (!email || otp.trim().length < 6)) ||
    (mode === "onboarding" && !username.trim());

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xl">
      <div
        ref={modalRef}
        className="w-full max-w-md rounded-3xl border border-white/15 bg-black/80 p-6 shadow-xl"
      >
        <h2 className="text-xl font-semibold text-white mb-4">{title}</h2>

        {(mode === "login" || mode === "signup") && (
          <>
            <label className="block text-xs text-white/70 mb-1">Email</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full mb-4 rounded-xl border border-white/20 bg-black/60 px-3 py-2 text-white"
              placeholder="nome@exemplo.com"
            />

            <label className="block text-xs text-white/70 mb-1">Password</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full mb-4 rounded-xl border border-white/20 bg-black/60 px-3 py-2 text-white"
              placeholder="••••••••"
            />
          </>
        )}

        {mode === "onboarding" && (
          <>
            <label className="block text-xs text-white/70 mb-1">Nome completo</label>
            <input
              type="text"
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              className="w-full mb-4 rounded-xl border border-white/20 bg-black/60 px-3 py-2 text-white"
              placeholder="Como te chamas?"
            />

            <label className="block text-xs text-white/70 mb-1">Username</label>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full mb-4 rounded-xl border border-white/20 bg-black/60 px-3 py-2 text-white"
              placeholder="@teuusername"
            />
          </>
        )}

        {mode === "verify" && (
          <>
            <label className="block text-xs text-white/70 mb-1">
              Código de verificação
            </label>
            <input
              type="text"
              maxLength={6}
              value={otp}
              onChange={(e) => setOtp(e.target.value)}
              className="w-full mb-4 rounded-xl border border-white/20 bg-black/60 px-3 py-2 text-white tracking-widest text-center"
              placeholder="000000"
            />
          </>
        )}

        {error && (
          <div className="mb-3 rounded-xl border border-red-400/50 bg-red-500/15 px-3 py-2 text-xs text-red-200">
            {error}
          </div>
        )}

        <button
          onClick={
            mode === "login"
              ? handleLogin
              : mode === "signup"
              ? handleSignup
              : mode === "verify"
              ? handleVerify
              : handleOnboardingSave
          }
          disabled={isPrimaryDisabled}
          className="w-full rounded-xl bg-gradient-to-r from-[#FF00C8] via-[#6BFFFF] to-[#1646F5] py-2.5 text-black font-semibold"
        >
          {loading
            ? "A processar..."
            : mode === "login"
            ? "Entrar"
            : mode === "signup"
            ? "Criar conta"
            : mode === "verify"
            ? "Confirmar"
            : "Guardar"}
        </button>

        <div className="mt-4 text-center text-xs text-white/60">
          {mode === "login" && (
            <button
              onClick={() => setMode("signup")}
              className="underline hover:text-white"
            >
              Ainda não tens conta? Criar conta
            </button>
          )}

          {mode === "signup" && (
            <button
              onClick={() => setMode("login")}
              className="underline hover:text-white"
            >
              Já tens conta? Iniciar sessão
            </button>
          )}

          {mode === "verify" && (
            <button
              onClick={() => setMode("login")}
              className="underline hover:text-white"
            >
              Voltar ao login
            </button>
          )}
        </div>
      </div>
    </div>
  );
}