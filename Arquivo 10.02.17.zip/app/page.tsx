// app/page.tsx
import Link from "next/link";
import { prisma } from "@/lib/prisma";
import { mapEventToCardDTO, type EventCardDTO } from "@/lib/events";
import { formatEuro } from "@/lib/money";

export const runtime = "nodejs";
export const revalidate = 300;

function formatDateRange(start: Date | null, end: Date | null) {
  if (!start || !end) return "Data a anunciar";
  const sameDay =
    start.getFullYear() === end.getFullYear() &&
    start.getMonth() === end.getMonth() &&
    start.getDate() === end.getDate();

  const dayOpts: Intl.DateTimeFormatOptions = {
    weekday: "short",
    day: "2-digit",
    month: "short",
  };

  const dateStr = start.toLocaleDateString("pt-PT", dayOpts);
  const endDateStr = end.toLocaleDateString("pt-PT", dayOpts);

  const startTime = start.toLocaleTimeString("pt-PT", { hour: "2-digit", minute: "2-digit" });
  const endTime = end.toLocaleTimeString("pt-PT", { hour: "2-digit", minute: "2-digit" });

  if (sameDay) return `${dateStr} · ${startTime} – ${endTime}`;
  return `${dateStr} ${startTime} · ${endDateStr} ${endTime}`;
}

function formatPrice(event: EventCardDTO) {
  if (event.isFree) return "Entrada gratuita";
  if (event.priceFrom == null) return "Preço a anunciar";
  return `Desde ${formatEuro(event.priceFrom)}`;
}

function buildEventLink(event: EventCardDTO) {
  return event.type === "EXPERIENCE" ? `/experiencias/${event.slug}` : `/eventos/${event.slug}`;
}

export default async function HomePage() {
  let events: EventCardDTO[] = [];

  try {
    const rows = await prisma.event.findMany({
      where: { status: "PUBLISHED" },
      orderBy: { startsAt: "asc" },
      select: {
        id: true,
        slug: true,
        title: true,
        description: true,
        type: true,
        startsAt: true,
        endsAt: true,
        locationName: true,
        locationCity: true,
        isFree: true,
        coverImageUrl: true,
        ticketTypes: {
          orderBy: { sortOrder: "asc" },
          select: { price: true },
        },
      },
      take: 18,
    });
    events = rows.map(mapEventToCardDTO).filter((e): e is EventCardDTO => e !== null);
  } catch (err) {
    console.error("HOME prisma error, rendering fallback:", { err });
  }

  const spotlight = events[0] ?? null;
  const yourEvents = events.slice(1, 5);
  const suggestions = events.slice(5, 9);
  const spotlightCover =
    spotlight?.coverImageUrl && spotlight.coverImageUrl.trim().length > 0
      ? spotlight.coverImageUrl
      : "/images/placeholder-event.jpg";

  return (
    <main className="min-h-screen bg-gradient-to-b from-[#050915] to-[#080b12] text-white">
      <section className="mx-auto max-w-4xl px-4 py-6 space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-lg font-semibold tracking-tight">ORYA</h1>
          <Link
            href="/explorar"
            className="text-[12px] text-[#6BFFFF] underline underline-offset-4"
          >
            Explorar
          </Link>
        </div>

        {/* Em Alta Agora */}
        <div className="rounded-3xl border border-white/12 bg-gradient-to-br from-[#0B1229] via-[#0A0E1A] to-[#05060f] shadow-[0_24px_70px_rgba(15,23,42,0.85)]">
          <div className="flex items-center justify-between px-4 py-3">
            <h2 className="text-sm font-semibold">Em alta agora</h2>
            <Link href="/explorar" className="text-[11px] text-[#6BFFFF]">
              Ver tudo
            </Link>
          </div>
          <div className="overflow-hidden rounded-2xl border border-white/10 mx-3 mb-3 bg-black/30">
            {spotlight ? (
              <>
                <div className="relative h-44 w-full overflow-hidden">
                  <div
                    className="absolute inset-0 bg-cover bg-center transition-transform duration-500"
                    style={{ backgroundImage: `url(${spotlightCover})`, transform: "scale(1.04)" }}
                    aria-hidden
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/55 to-transparent" />
                  <div className="absolute bottom-3 left-4 right-4 flex items-end justify-between gap-3">
                    <div>
                      <p className="text-xs font-semibold text-zinc-50">{spotlight.title}</p>
                      <p className="mt-0.5 text-[11px] text-zinc-200">
                        {formatDateRange(spotlight.startsAt, spotlight.endsAt)}
                      </p>
                    </div>
                    <p className="rounded-full bg-black/75 px-3 py-1 text-[11px] font-medium text-zinc-50">
                      {formatPrice(spotlight)}
                    </p>
                  </div>
                </div>
                <div className="space-y-3 px-4 pb-4 pt-3">
                  <p className="text-xs text-zinc-300">
                    Evento em destaque. Abre para veres todos os detalhes.
                  </p>
                  <Link
                    href={buildEventLink(spotlight)}
                    className="mt-1 inline-flex w-full items-center justify-center rounded-2xl bg-gradient-to-r from-[#FF00C8] via-[#6BFFFF] to-[#1646F5] px-4 py-2 text-xs font-semibold text-black shadow-lg shadow-[#6bffff80] hover:brightness-110"
                  >
                    Abrir página do evento
                  </Link>
                </div>
              </>
            ) : (
              <div className="px-4 py-6 text-sm text-zinc-200 space-y-2">
                <p>Ainda não há eventos em destaque.</p>
                <p className="text-[12px] text-zinc-400">
                  Assim que houver, aparecem aqui para ti.
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Os teus eventos */}
        <div className="rounded-3xl border border-white/10 bg-black/25 p-4 shadow-[0_16px_50px_rgba(0,0,0,0.6)] space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-semibold">Os teus eventos</h2>
            <Link href="/explorar" className="text-[11px] text-[#6BFFFF]">
              Ver mais
            </Link>
          </div>
          {yourEvents.length > 0 ? (
            <div className="grid gap-3 sm:grid-cols-2">
              {yourEvents.map((ev) => (
                <Link
                  key={ev.id}
                  href={buildEventLink(ev)}
                  className="rounded-2xl border border-white/12 bg-white/5 p-3 hover:border-[#6BFFFF]/70 transition"
                >
                  <p className="text-[11px] text-zinc-400">
                    {formatDateRange(ev.startsAt, ev.endsAt)}
                  </p>
                  <p className="text-sm font-semibold text-white line-clamp-2">{ev.title}</p>
                  <p className="text-[11px] text-zinc-300 mt-1">{formatPrice(ev)}</p>
                </Link>
              ))}
            </div>
          ) : (
            <div className="rounded-2xl border border-white/10 bg-white/5 p-4 text-sm text-zinc-300">
              Ainda não tens eventos. Explora e junta-te a um evento para aparecer aqui.
            </div>
          )}
        </div>

        {/* Sugestões personalizadas */}
        <div className="rounded-3xl border border-white/10 bg-black/20 p-4 shadow-[0_16px_50px_rgba(0,0,0,0.6)] space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-semibold">Sugestões personalizadas</h2>
          </div>
          {suggestions.length > 0 ? (
            <div className="space-y-2">
              {suggestions.map((ev) => (
                <Link
                  key={ev.id}
                  href={buildEventLink(ev)}
                  className="flex items-center justify-between rounded-2xl border border-white/12 bg-white/5 px-3 py-2 hover:border-[#6BFFFF]/70"
                >
                  <div>
                    <p className="text-xs text-zinc-300">{formatDateRange(ev.startsAt, ev.endsAt)}</p>
                    <p className="text-sm font-semibold text-white line-clamp-1">{ev.title}</p>
                  </div>
                  <span className="text-[11px] text-[#6BFFFF]">Ver</span>
                </Link>
              ))}
            </div>
          ) : (
            <div className="rounded-2xl border border-white/10 bg-white/5 p-4 text-sm text-zinc-300">
              Ainda estamos a conhecer-te. À medida que usares a ORYA, as sugestões vão aparecer aqui.
            </div>
          )}
        </div>

        {/* Oportunidades perto de ti */}
        <div className="rounded-3xl border border-white/10 bg-black/20 p-4 shadow-[0_16px_50px_rgba(0,0,0,0.6)] space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-semibold">Oportunidades perto de ti agora</h2>
          </div>
          <div className="rounded-2xl border border-white/10 bg-white/5 p-4 text-sm text-zinc-300">
            Sem oportunidades perto de ti neste momento. Vais ser o primeiro a saber quando surgir algo porreiro.
          </div>
        </div>

        {/* Amigos vão a... */}
        <div className="rounded-3xl border border-white/10 bg-black/25 p-4 shadow-[0_16px_50px_rgba(0,0,0,0.6)] space-y-2">
          <h2 className="text-sm font-semibold">Amigos vão a…</h2>
          <p className="text-sm text-zinc-300">
            Quando os teus amigos começarem a ir a eventos, vais ver aqui onde eles vão.
          </p>
        </div>
      </section>
    </main>
  );
}
