-- Preferred side enum
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'PadelPreferredSide') THEN
    CREATE TYPE "app_v3"."PadelPreferredSide" AS ENUM ('ESQUERDA', 'DIREITA', 'QUALQUER');
  END IF;
END$$;

-- Padel player profile extensions
ALTER TABLE "app_v3"."padel_player_profiles"
  ADD COLUMN IF NOT EXISTS "display_name" text,
  ADD COLUMN IF NOT EXISTS "preferred_side" "app_v3"."PadelPreferredSide",
  ADD COLUMN IF NOT EXISTS "club_name" text,
  ADD COLUMN IF NOT EXISTS "birth_date" timestamp(6);

-- Link pairing slots to player profile
ALTER TABLE "app_v3"."padel_pairing_slots"
  ADD COLUMN IF NOT EXISTS "player_profile_id" integer;

ALTER TABLE "app_v3"."padel_pairing_slots"
  ADD CONSTRAINT "padel_pairing_slots_player_profile_fk"
  FOREIGN KEY ("player_profile_id") REFERENCES "app_v3"."padel_player_profiles"("id") ON DELETE SET NULL ON UPDATE NO ACTION;

CREATE INDEX IF NOT EXISTS "padel_pairing_slots_player_profile_idx"
  ON "app_v3"."padel_pairing_slots"("player_profile_id");

-- Matches: align with pairings (keep legacy team fields)
ALTER TABLE "app_v3"."padel_matches"
  ADD COLUMN IF NOT EXISTS "pairing_a_id" integer,
  ADD COLUMN IF NOT EXISTS "pairing_b_id" integer,
  ADD COLUMN IF NOT EXISTS "group_label" text,
  ADD COLUMN IF NOT EXISTS "round_type" text,
  ADD COLUMN IF NOT EXISTS "winner_pairing_id" integer,
  ADD COLUMN IF NOT EXISTS "score_sets" jsonb,
  ADD COLUMN IF NOT EXISTS "court_name" text;

ALTER TABLE "app_v3"."padel_matches"
  ADD CONSTRAINT "padel_matches_pairing_a_fk" FOREIGN KEY ("pairing_a_id") REFERENCES "app_v3"."padel_pairings"("id") ON DELETE SET NULL ON UPDATE NO ACTION;

ALTER TABLE "app_v3"."padel_matches"
  ADD CONSTRAINT "padel_matches_pairing_b_fk" FOREIGN KEY ("pairing_b_id") REFERENCES "app_v3"."padel_pairings"("id") ON DELETE SET NULL ON UPDATE NO ACTION;

ALTER TABLE "app_v3"."padel_matches"
  ADD CONSTRAINT "padel_matches_winner_fk" FOREIGN KEY ("winner_pairing_id") REFERENCES "app_v3"."padel_pairings"("id") ON DELETE SET NULL ON UPDATE NO ACTION;

CREATE INDEX IF NOT EXISTS "padel_matches_pairings_idx"
  ON "app_v3"."padel_matches"("pairing_a_id","pairing_b_id");
