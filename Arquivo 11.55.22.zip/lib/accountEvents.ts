import { prisma } from "@/lib/prisma";

export async function logAccountEvent(params: {
  userId: string;
  type: "account_delete_requested" | "account_delete_cancelled" | "account_delete_completed" | "account_restored";
  metadata?: Record<string, unknown>;
}) {
  try {
    await prisma.accountEventLog.create({
      data: {
        userId: params.userId,
        type: params.type,
        metadata: params.metadata ?? {},
      },
    });
  } catch (err) {
    console.warn("[accountEvents] failed to log event", err);
  }
}
