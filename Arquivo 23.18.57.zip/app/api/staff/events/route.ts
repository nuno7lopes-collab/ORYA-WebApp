

import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { createSupabaseServer } from "@/lib/supabaseServer";
import { ensureAuthenticated } from "@/lib/security";

export async function GET() {
  try {
    const supabase = await createSupabaseServer();
    const user = await ensureAuthenticated(supabase);

    // Buscar assignments ativos para este utilizador
    const assignments = await prisma.staffAssignment.findMany({
      where: {
        userId: user.id,
        revokedAt: null,
      },
      include: {
        organizer: true,
        event: true,
      },
    });

    if (!assignments.length) {
      return NextResponse.json(
        {
          ok: true,
          events: [],
        },
        { status: 200 }
      );
    }

    // Separar os tipos de permissões
    const organizerIds = assignments
      .filter((a) => a.scope === "GLOBAL")
      .map((a) => a.organizerId)
      .filter((id): id is number => id !== null && id !== undefined);

    const eventIds = assignments
      .filter((a) => a.scope === "EVENT")
      .map((a) => a.eventId)
      .filter((id): id is number => id !== null && id !== undefined);

    if (!organizerIds.length && !eventIds.length) {
      return NextResponse.json(
        {
          ok: true,
          events: [],
        },
        { status: 200 }
      );
    }

    const events = await prisma.event.findMany({
      where: {
        OR: [
          organizerIds.length
            ? {
                organizerId: { in: organizerIds },
              }
            : undefined,
          eventIds.length
            ? {
                id: { in: eventIds },
              }
            : undefined,
        ].filter(Boolean) as any,
      },
      include: {
        organizer: true,
      },
      orderBy: {
        startsAt: "asc",
      },
    });

    const payload = events.map((event) => ({
      id: event.id,
      slug: event.slug,
      title: event.title,
      description: event.description,
      startsAt: event.startsAt,
      endsAt: event.endsAt,
      locationName: event.locationName,
      locationCity: event.locationCity,
      organizerName: event.organizer?.displayName ?? null,
    }));

    return NextResponse.json(
      {
        ok: true,
        events: payload,
      },
      { status: 200 }
    );
  } catch (err) {
    console.error("GET /api/staff/events error:", err);
    return NextResponse.json(
      {
        ok: false,
        error: "Erro interno ao carregar eventos de staff.",
      },
      { status: 500 }
    );
  }
}