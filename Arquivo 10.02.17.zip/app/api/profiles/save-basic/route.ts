

// app/api/profiles/save-basic/route.ts
import { NextRequest, NextResponse } from "next/server";
import { createSupabaseServer } from "@/lib/supabaseServer";
import { prisma } from "@/lib/prisma";

interface SaveBasicBody {
  fullName?: string;
  username?: string;
  avatarUrl?: string | null;
}

export async function POST(req: NextRequest) {
  const startedAt = Date.now();
  try {
    const supabase = await createSupabaseServer();

    const {
      data: { user },
      error,
    } = await supabase.auth.getUser();

    if (error || !user) {
      return NextResponse.json(
        { ok: false, error: "Não autenticado." },
        { status: 401 }
      );
    }

    const userId = user.id;

    const body = (await req.json().catch(() => null)) as SaveBasicBody | null;

    if (!body || typeof body !== "object") {
      return NextResponse.json(
        { ok: false, error: "Body inválido." },
        { status: 400 }
      );
    }

    const rawFullName = body.fullName ?? "";
    const rawUsername = body.username ?? "";
    const avatarProvided = Object.prototype.hasOwnProperty.call(body, "avatarUrl");
    const rawAvatar = body.avatarUrl;

    const fullName = rawFullName.trim();
    const username = rawUsername.trim().toLowerCase();
    const avatarUrl =
      typeof rawAvatar === "string"
        ? rawAvatar.trim() || null
        : rawAvatar === null
          ? null
          : undefined;

    if (!fullName || !username) {
      return NextResponse.json(
        {
          ok: false,
          error: "Nome completo e username são obrigatórios.",
        },
        { status: 400 }
      );
    }

    // Verificar se username já está em uso por outro utilizador
    const existing = await prisma.profile.findFirst({
      where: {
        username,
        NOT: { id: userId },
      },
    });

    if (existing) {
      return NextResponse.json(
        {
          ok: false,
          error: "Este username já está a ser utilizado.",
          code: "USERNAME_TAKEN",
        },
        { status: 409 }
      );
    }

    const profile = await prisma.profile.upsert({
      where: { id: userId },
      update: {
        fullName,
        username,
        onboardingDone: true,
        ...(avatarProvided ? { avatarUrl } : {}),
      },
      create: {
        id: userId,
        fullName,
        username,
        onboardingDone: true,
        roles: ["user"],
        avatarUrl: avatarProvided ? avatarUrl ?? null : null,
      },
    });

    const safeProfile = {
      id: profile.id,
      username: profile.username,
      fullName: profile.fullName,
      avatarUrl: profile.avatarUrl,
      bio: profile.bio,
      city: profile.city,
      favouriteCategories: profile.favouriteCategories,
      onboardingDone: profile.onboardingDone,
      roles: profile.roles,
    };

    return NextResponse.json(
      {
        ok: true,
        profile: safeProfile,
      },
      {
        status: 200,
        headers: { "x-total-ms": (Date.now() - startedAt).toString() },
      }
    );
  } catch (err) {
    console.error("POST /api/profiles/save-basic error:", err);
    return NextResponse.json(
      {
        ok: false,
        error: "Erro inesperado ao guardar perfil.",
        code: "INTERNAL_ERROR",
      },
      {
        status: 500,
        headers: { "x-total-ms": (Date.now() - startedAt).toString() },
      }
    );
  }
}
