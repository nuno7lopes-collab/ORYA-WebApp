import { redirect } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { createSupabaseServer } from "@/lib/supabaseServer";
import { getActiveOrganizerForUser } from "@/lib/organizerContext";
import DashboardClient from "./DashboardClient";

export const runtime = "nodejs";

export default async function OrganizerRouterPage() {
  const supabase = await createSupabaseServer();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    redirect("/login?redirectTo=/organizador");
  }

  // 1) Contar memberships do utilizador (se tabela não existir em dev, assume 0 para cair no onboarding)
  let membershipCount = 0;
  try {
    membershipCount = await prisma.organizerMember.count({ where: { userId: user.id } });
  } catch (err: unknown) {
    const msg =
      typeof err === "object" && err && "message" in err ? String((err as { message?: unknown }).message) : "";
    if (!(msg.includes("does not exist") || msg.includes("organizer_members"))) {
      throw err;
    }
  }

  if (membershipCount === 0) {
    redirect("/organizador/become");
  }

  // 2) Ver se existe organização ativa
  let activeOrganizerId: number | null = null;
  try {
    const { organizer } = await getActiveOrganizerForUser(user.id);
    activeOrganizerId = organizer?.id ?? null;
  } catch (err: unknown) {
    const msg =
      typeof err === "object" && err && "message" in err ? String((err as { message?: unknown }).message) : "";
    if (!(msg.includes("does not exist") || msg.includes("organizer_members"))) {
      throw err;
    }
  }

  if (!activeOrganizerId) {
    redirect("/organizador/organizations");
  }

  // 3) Tem organização ativa → mostra o dashboard (overview por omissão no client)
  return <DashboardClient />;
}
