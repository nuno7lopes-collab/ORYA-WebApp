import type { NextWebVitalsMetric } from "next/app";

/**
 * Lightweight Web Vitals logger.
 * Logs metrics to console and optionally sends them to an endpoint defined in NEXT_PUBLIC_WEB_VITALS_ENDPOINT.
 */
export function reportWebVitals(metric: NextWebVitalsMetric) {
  const payload = {
    id: metric.id,
    name: metric.name,
    label: metric.label,
    value: metric.value,
    navigationType: typeof window !== "undefined" ? performance?.navigation?.type : undefined,
    url: typeof window !== "undefined" ? window.location.href : undefined,
    userAgent: typeof navigator !== "undefined" ? navigator.userAgent : undefined,
    timestamp: Date.now(),
  };

  // Console for quick inspection during manual tests
  // eslint-disable-next-line no-console
  console.info("[WebVitals]", payload);

  // Optional: send to your own endpoint without blocking the UI
  const endpoint =
    process.env.NEXT_PUBLIC_WEB_VITALS_ENDPOINT || "/api/web-vitals";
  if (endpoint) {
    try {
      const body = JSON.stringify(payload);
      if (navigator.sendBeacon) {
        navigator.sendBeacon(endpoint, body);
      } else {
        void fetch(endpoint, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body,
          keepalive: true,
        });
      }
    } catch (err) {
      // eslint-disable-next-line no-console
      console.warn("[WebVitals] Failed to send metric", err);
    }
  }
}
