import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

const DEFAULT_PAGE_SIZE = 12;

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const cursor = searchParams.get("cursor");
  const limitParam = searchParams.get("limit");

  const take = limitParam
    ? Math.min(parseInt(limitParam, 10) || DEFAULT_PAGE_SIZE, 50)
    : DEFAULT_PAGE_SIZE;

  let items: any[] = [];
  let nextCursor: string | null = null;

  try {
    const prismaAny: any = prisma;

    const query: any = {
      orderBy: { startsAt: "asc" },
      take: take + 1, // +1 para sabermos se há mais páginas
    };

    if (cursor) {
      query.skip = 1;
      query.cursor = { id: cursor };
    }

    const events: any[] = await prismaAny.event.findMany(query);

    if (events.length > take) {
      const next = events.pop();
      nextCursor = next?.id ?? null;
    }

    items = events.map((e: any) => ({
      id: e.id,
      slug: e.slug,
      title: e.title,
      description: e.description ?? null,
      startsAt: e.startsAt
        ? (typeof e.startsAt === "string"
            ? e.startsAt
            : e.startsAt.toISOString?.() ?? null)
        : null,
      locationName: e.locationName ?? null,
      locationCity: e.locationCity ?? null,
      priceFromCents: e.priceFromCents ?? null,
    }));
  } catch (error) {
    console.error("[api/eventos/list] Erro ao carregar eventos, fallback para lista vazia:", error);
    items = [];
    nextCursor = null;
  }

  return NextResponse.json({
    items,
    pagination: {
      nextCursor,
      hasMore: !!nextCursor,
    },
  });
}