"use client";

import { useEffect, useMemo, useState } from "react";
import useSWR from "swr";
import { useRouter } from "next/navigation";
import { useUser } from "@/app/hooks/useUser";
import { useAuthModal } from "@/app/components/autenticação/AuthModalContext";
import { isValidPhone, sanitizePhone } from "@/lib/phone";

type OrganizerMeResponse = {
  ok: boolean;
  organizer: {
    id: number;
    displayName: string | null;
    username?: string | null;
    businessName: string | null;
    entityType: string | null;
    city: string | null;
    payoutIban: string | null;
    language?: string | null;
    publicListingEnabled?: boolean | null;
    alertsEmail?: string | null;
    alertsSalesEnabled?: boolean | null;
    alertsPayoutEnabled?: boolean | null;
    brandingAvatarUrl?: string | null;
    brandingPrimaryColor?: string | null;
    brandingSecondaryColor?: string | null;
    organizationKind?: string | null;
    padelDefaults?: {
      shortName?: string | null;
      city?: string | null;
      address?: string | null;
      courts?: number;
      hours?: string | null;
      ruleSetId?: number | null;
      favoriteCategories?: number[];
    } | null;
  } | null;
  profile: {
    fullName: string | null;
    city: string | null;
    contactPhone?: string | null;
  } | null;
  contactEmail?: string | null;
  membershipRole?: string | null;
};

const fetcher = (url: string) => fetch(url).then((r) => r.json());

export default function OrganizerSettingsPage() {
  const router = useRouter();
  const { user } = useUser();
  const { openModal } = useAuthModal();
  const { data, isLoading, mutate } = useSWR<OrganizerMeResponse>(user ? "/api/organizador/me" : null, fetcher, {
    revalidateOnFocus: false,
  });

  const organizer = data?.organizer ?? null;
  const profile = data?.profile ?? null;
  const contactEmailFromAccount = data?.contactEmail ?? null;

  const [displayName, setDisplayName] = useState("");
  const [businessName, setBusinessName] = useState("");
  const [entityType, setEntityType] = useState("");
  const [city, setCity] = useState("");
  const [contactEmail, setContactEmail] = useState("");
  const [contactPhone, setContactPhone] = useState("");
  const [phoneError, setPhoneError] = useState<string | null>(null);
  const [payoutIban, setPayoutIban] = useState("");
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  const [prefPublicListing, setPrefPublicListing] = useState(true);
  const [alertsEmail, setAlertsEmail] = useState("");
  const [alertsSalesEnabled, setAlertsSalesEnabled] = useState(true);
  const [alertsPayoutEnabled, setAlertsPayoutEnabled] = useState(false);
  const [brandingAvatarUrl, setBrandingAvatarUrl] = useState("");
  const [brandingPrimaryColor, setBrandingPrimaryColor] = useState("");
  const [brandingSecondaryColor, setBrandingSecondaryColor] = useState("");
  const [brandingUploading, setBrandingUploading] = useState(false);
  const [prefLanguage, setPrefLanguage] = useState("pt");
  const [organizationKind, setOrganizationKind] = useState("PESSOA_SINGULAR");
  const [padelShortName, setPadelShortName] = useState("");
  const [padelCity, setPadelCity] = useState("");
  const [padelAddress, setPadelAddress] = useState("");
  const [padelCourts, setPadelCourts] = useState("");
  const [padelHours, setPadelHours] = useState("");
  const [padelRuleSetId, setPadelRuleSetId] = useState("");
  const [padelFavCategories, setPadelFavCategories] = useState("");
  const [dangerConfirm, setDangerConfirm] = useState("");
  const [dangerFeedback, setDangerFeedback] = useState<string | null>(null);
  const [dangerLoading, setDangerLoading] = useState(false);

  useEffect(() => {
    if (!organizer) return;
    setDisplayName(organizer.displayName ?? "");
    setBusinessName(organizer.businessName ?? "");
    setEntityType(organizer.entityType ?? "");
    setCity(organizer.city ?? profile?.city ?? "");
    setPayoutIban(organizer.payoutIban ?? "");
    if (profile?.contactPhone) setContactPhone(profile.contactPhone);
    if (contactEmailFromAccount) setContactEmail(contactEmailFromAccount);
    setPrefPublicListing(organizer.publicListingEnabled ?? true);
    setAlertsEmail((organizer.alertsEmail as string | null) ?? contactEmailFromAccount ?? "");
    setAlertsSalesEnabled((organizer.alertsSalesEnabled as boolean | null) ?? true);
    setAlertsPayoutEnabled((organizer.alertsPayoutEnabled as boolean | null) ?? false);
    setBrandingAvatarUrl((organizer.brandingAvatarUrl as string | null) ?? "");
    setBrandingPrimaryColor((organizer.brandingPrimaryColor as string | null) ?? "");
    setBrandingSecondaryColor((organizer.brandingSecondaryColor as string | null) ?? "");
    setPrefLanguage((organizer.language as string | null) ?? "pt");
    setOrganizationKind((organizer.organizationKind as string | null) ?? "PESSOA_SINGULAR");
    const padel = organizer.padelDefaults;
    setPadelShortName(padel?.shortName ?? "");
    setPadelCity(padel?.city ?? organizer.city ?? "");
    setPadelAddress(padel?.address ?? "");
    setPadelCourts(padel?.courts ? String(padel.courts) : "");
    setPadelHours(padel?.hours ?? "");
    setPadelRuleSetId(padel?.ruleSetId ? String(padel.ruleSetId) : "");
    setPadelFavCategories(padel?.favoriteCategories?.length ? padel.favoriteCategories.join(",") : "");
  }, [organizer, profile, contactEmailFromAccount]);

  const hasOrganizer = useMemo(() => organizer && data?.ok, [organizer, data]);
  const membershipRole = data?.membershipRole ?? null;
  const isOwner = membershipRole === "OWNER";
  const dangerReady = dangerConfirm.trim().toUpperCase() === "APAGAR";

  async function handleSave() {
    if (!user) {
      openModal({ mode: "login", redirectTo: "/organizador/settings", showGoogle: true });
      return;
    }
    if (contactPhone && !isValidPhone(contactPhone)) {
      setPhoneError("Telefone inválido. Introduz um número válido (podes incluir indicativo, ex.: +351...).");
      return;
    }
    setSaving(true);
    setMessage(null);
    try {
      const res = await fetch("/api/organizador/me", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          displayName,
          businessName,
          entityType,
          city,
          payoutIban,
          fullName: profile?.fullName ?? displayName,
          contactPhone,
          language: prefLanguage,
          publicListingEnabled: prefPublicListing,
          alertsEmail,
          alertsSalesEnabled,
          alertsPayoutEnabled,
          brandingAvatarUrl,
          brandingPrimaryColor,
          brandingSecondaryColor,
          organizationKind,
          padelDefaultShortName: padelShortName,
          padelDefaultCity: padelCity,
          padelDefaultAddress: padelAddress,
          padelDefaultCourts: padelCourts ? Number(padelCourts) : undefined,
          padelDefaultHours: padelHours,
          padelDefaultRuleSetId: padelRuleSetId ? Number(padelRuleSetId) : undefined,
          padelFavoriteCategories: padelFavCategories
            .split(",")
            .map((v) => v.trim())
            .filter(Boolean)
            .map((v) => Number(v))
            .filter((n) => Number.isFinite(n)),
        }),
      });
      const json = await res.json().catch(() => null);
      if (!res.ok || json?.ok === false) {
        setMessage(json?.error || "Não foi possível guardar as definições.");
      } else {
        setMessage("Definições guardadas.");
        mutate();
      }
    } catch (err) {
      console.error("[organizador/settings] save", err);
      setMessage("Erro inesperado ao guardar.");
    } finally {
      setSaving(false);
    }
  }

  const handleLogoUpload = async (file: File | null) => {
    if (!file) return;
    setBrandingUploading(true);
    setMessage(null);
    try {
      const formData = new FormData();
      formData.append("file", file);
      const uploadRes = await fetch("/api/upload", { method: "POST", body: formData });
      const uploadJson = await uploadRes.json().catch(() => null);
      if (!uploadRes.ok || !uploadJson?.url) {
        setMessage(uploadJson?.error || "Falha no upload do logo.");
        return;
      }
      setBrandingAvatarUrl(uploadJson.url);
      const saveRes = await fetch("/api/organizador/me", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ brandingAvatarUrl: uploadJson.url }),
      });
      const saveJson = await saveRes.json().catch(() => null);
      if (!saveRes.ok || saveJson?.ok === false) {
        setMessage(saveJson?.error || "Não foi possível guardar o logo.");
      } else {
        setMessage("Logo atualizado.");
        mutate();
      }
    } catch (err) {
      console.error("[organizador/settings] upload logo", err);
      setMessage("Erro inesperado ao fazer upload.");
    } finally {
      setBrandingUploading(false);
    }
  };

  const handleDeleteOrganization = async () => {
    if (!organizer?.id) return;
    if (dangerConfirm.trim().toUpperCase() !== "APAGAR") {
      setDangerFeedback("Escreve APAGAR para confirmares.");
      return;
    }
    setDangerLoading(true);
    setDangerFeedback(null);
    try {
      const res = await fetch(`/api/organizador/organizations/${organizer.id}`, { method: "DELETE" });
      const json = await res.json().catch(() => null);
      if (!res.ok || json?.ok === false) {
        setDangerFeedback(json?.error || "Não foi possível apagar a organização.");
      } else {
        setDangerFeedback("Organização apagada. Redirecionámos-te para gerir outras.");
        setDangerConfirm("");
        router.push("/organizador/organizations");
      }
    } catch (err) {
      console.error("[organizador/settings] delete", err);
      setDangerFeedback("Erro inesperado ao apagar.");
    } finally {
      setDangerLoading(false);
    }
  };

  if (!user) {
    return (
      <div className="mx-auto max-w-4xl px-4 py-10 space-y-4 text-white md:px-6 lg:px-8">
        <h1 className="text-2xl font-semibold">Definições do organizador</h1>
        <p>Precisas de iniciar sessão para aceder a estas definições.</p>
        <button
          type="button"
          onClick={() => openModal({ mode: "login", redirectTo: "/organizador/settings", showGoogle: true })}
          className="rounded-full bg-white px-4 py-2 text-sm font-semibold text-black"
        >
          Entrar
        </button>
      </div>
    );
  }

  if (isLoading || !hasOrganizer) {
    return (
      <div className="mx-auto max-w-4xl px-4 py-10 text-white md:px-6 lg:px-8">
        {isLoading ? "A carregar definições…" : "Ativa a conta de organizador para gerir estas definições."}
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-5xl px-4 py-10 space-y-6 text-white md:px-6 lg:px-8">
      <div className="space-y-1">
        <p className="text-[11px] uppercase tracking-[0.3em] text-white/60">Definições</p>
        <div className="flex flex-wrap items-center gap-3">
          <div>
            <h1 className="text-3xl font-semibold">Perfil do organizador</h1>
            <p className="text-sm text-white/65">Dados públicos, faturação e preferências de comunicação.</p>
          </div>
          {organizer?.username && (
            <a
              href={`/org/${organizer.username}`}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/5 px-3 py-1.5 text-[12px] text-white hover:bg-white/10"
            >
              Ver página pública ↗
            </a>
          )}
        </div>
      </div>

      <section className="rounded-2xl border border-white/10 bg-white/5 p-4 space-y-3 shadow-[0_16px_50px_rgba(0,0,0,0.45)]">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-semibold">Dados públicos</h2>
            <p className="text-[12px] text-white/65">Nome visível, localização e contactos públicos.</p>
          </div>
          <button
            type="button"
            onClick={handleSave}
            disabled={saving}
            className="rounded-full bg-gradient-to-r from-[#FF00C8] via-[#6BFFFF] to-[#1646F5] px-4 py-2 text-sm font-semibold text-black shadow disabled:opacity-60"
          >
            {saving ? "A guardar…" : "Guardar"}
          </button>
        </div>
        <div className="grid gap-3 md:grid-cols-2">
          <div className="space-y-1">
            <label className="text-[12px] text-white/70">Tipo de entidade *</label>
            <select
              value={entityType}
              onChange={(e) => setEntityType(e.target.value)}
              className="w-full rounded-xl border border-white/15 bg-black/40 px-3 py-2 text-sm outline-none focus:border-[#6BFFFF]"
            >
              <option value="">Seleciona</option>
              <option value="PESSOA_SINGULAR">Pessoa singular</option>
              <option value="EMPRESA">Empresa</option>
              <option value="ASSOCIACAO">Associação</option>
            </select>
          </div>
          <div className="space-y-1">
            <label className="text-[12px] text-white/70">Nome do organizador *</label>
            <input
              value={businessName}
              onChange={(e) => setBusinessName(e.target.value)}
              className="w-full rounded-xl border border-white/15 bg-black/40 px-3 py-2 text-sm outline-none focus:border-[#6BFFFF]"
              placeholder="Ex.: Casa Guedes, ORYA TEAM"
            />
          </div>
          <div className="space-y-1">
            <label className="text-[12px] text-white/70">Nome público (opcional)</label>
            <input
              value={displayName}
              onChange={(e) => setDisplayName(e.target.value)}
              className="w-full rounded-xl border border-white/15 bg-black/40 px-3 py-2 text-sm outline-none focus:border-[#6BFFFF]"
              placeholder="Ex.: ORYA"
            />
          </div>
          <div className="space-y-1">
            <label className="text-[12px] text-white/70">Cidade base *</label>
            <input
              value={city}
              onChange={(e) => setCity(e.target.value)}
              className="w-full rounded-xl border border-white/15 bg-black/40 px-3 py-2 text-sm outline-none focus:border-[#6BFFFF]"
              placeholder="Lisboa, Porto..."
            />
          </div>
        </div>
        <div className="grid gap-3 md:grid-cols-2">
          <div className="space-y-1">
            <label className="text-[12px] text-white/70">Email de contacto *</label>
            <input
              value={contactEmail}
              readOnly
              className="w-full rounded-xl border border-white/15 bg-black/25 px-3 py-2 text-sm text-white/80"
              placeholder="email@exemplo.pt"
            />
            <p className="text-[11px] text-white/50">Usamos o email da tua conta. Altera em /me/settings se precisares.</p>
          </div>
          <div className="space-y-1">
            <label className="text-[12px] text-white/70">Telefone (opcional)</label>
            <input
              value={contactPhone}
              onChange={(e) => {
                const sanitized = sanitizePhone(e.target.value);
                setContactPhone(sanitized);
                if (sanitized && !isValidPhone(sanitized)) {
                  setPhoneError("Telefone inválido. Introduz um número válido (podes incluir indicativo, ex.: +351...).");
                } else {
                  setPhoneError(null);
                }
              }}
              inputMode="tel"
              pattern="\\+?\\d{6,15}"
              maxLength={18}
              className={`w-full rounded-xl border bg-black/40 px-3 py-2 text-sm outline-none focus:border-[#6BFFFF] ${
                phoneError ? "border-red-400/60" : "border-white/15"
              }`}
              placeholder="+351912345678"
            />
            {phoneError && <p className="text-[11px] text-red-300">{phoneError}</p>}
          </div>
        </div>
        {message && <p className="text-[12px] text-white/70">{message}</p>}
      </section>

      <section className="rounded-2xl border border-white/10 bg-black/30 p-4 space-y-3 shadow-[0_16px_50px_rgba(0,0,0,0.45)]">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-semibold">Tipo de organização & defaults Padel</h2>
            <p className="text-[12px] text-white/65">Usados para pré-preencher o wizard Padel.</p>
          </div>
          <button
            type="button"
            onClick={handleSave}
            disabled={saving}
            className="rounded-full border border-white/20 px-4 py-2 text-sm font-semibold text-white shadow hover:bg-white/10 disabled:opacity-60"
          >
            {saving ? "A guardar…" : "Guardar"}
          </button>
        </div>
        <div className="grid gap-3 md:grid-cols-2">
          <label className="space-y-1 text-sm">
            Tipo de organização
            <select
              value={organizationKind}
              onChange={(e) => setOrganizationKind(e.target.value)}
              className="w-full rounded-xl border border-white/15 bg-black/40 px-3 py-2 text-sm outline-none focus:border-[#6BFFFF]"
            >
              <option value="CLUBE_PADEL">Clube de padel</option>
              <option value="RESTAURANTE">Restaurante</option>
              <option value="EMPRESA_EVENTOS">Empresa de eventos</option>
              <option value="ASSOCIACAO">Associação</option>
              <option value="PESSOA_SINGULAR">Pessoa singular</option>
            </select>
          </label>
          <div className="space-y-1 text-sm">
            <p className="text-[12px] text-white/70 font-semibold">Defaults de Padel</p>
            <p className="text-[11px] text-white/55">Aplicados automaticamente no wizard de torneios.</p>
          </div>
        </div>
        <div className="grid gap-3 md:grid-cols-2">
          <label className="space-y-1 text-sm">
            Nome curto (torneios)
            <input
              value={padelShortName}
              onChange={(e) => setPadelShortName(e.target.value)}
              className="w-full rounded-xl border border-white/15 bg-black/40 px-3 py-2 text-sm outline-none focus:border-[#6BFFFF]"
              placeholder="Ex.: Clube XPTO Padel"
            />
          </label>
          <label className="space-y-1 text-sm">
            Cidade padrão
            <input
              value={padelCity}
              onChange={(e) => setPadelCity(e.target.value)}
              className="w-full rounded-xl border border-white/15 bg-black/40 px-3 py-2 text-sm outline-none focus:border-[#6BFFFF]"
              placeholder="Porto, Lisboa…"
            />
          </label>
        </div>
        <div className="grid gap-3 md:grid-cols-2">
          <label className="space-y-1 text-sm">
            Morada padrão
            <input
              value={padelAddress}
              onChange={(e) => setPadelAddress(e.target.value)}
              className="w-full rounded-xl border border-white/15 bg-black/40 px-3 py-2 text-sm outline-none focus:border-[#6BFFFF]"
              placeholder="Rua e número"
            />
          </label>
          <label className="space-y-1 text-sm">
            Nº de courts
            <input
              type="number"
              min={0}
              value={padelCourts}
              onChange={(e) => setPadelCourts(e.target.value)}
              className="w-full rounded-xl border border-white/15 bg-black/40 px-3 py-2 text-sm outline-none focus:border-[#6BFFFF]"
              placeholder="Ex.: 4"
            />
          </label>
        </div>
        <div className="grid gap-3 md:grid-cols-2">
          <label className="space-y-1 text-sm">
            Horário típico
            <input
              value={padelHours}
              onChange={(e) => setPadelHours(e.target.value)}
              className="w-full rounded-xl border border-white/15 bg-black/40 px-3 py-2 text-sm outline-none focus:border-[#6BFFFF]"
              placeholder="Ex.: 09:00–22:00"
            />
          </label>
          <label className="space-y-1 text-sm">
            Rule set ID (opcional)
            <input
              value={padelRuleSetId}
              onChange={(e) => setPadelRuleSetId(e.target.value)}
              className="w-full rounded-xl border border-white/15 bg-black/40 px-3 py-2 text-sm outline-none focus:border-[#6BFFFF]"
              placeholder="ID de rule set"
            />
          </label>
        </div>
        <label className="space-y-1 text-sm">
          Categorias favoritas (IDs separados por vírgula)
          <input
            value={padelFavCategories}
            onChange={(e) => setPadelFavCategories(e.target.value)}
            className="w-full rounded-xl border border-white/15 bg-black/40 px-3 py-2 text-sm outline-none focus:border-[#6BFFFF]"
            placeholder="Ex.: 1,2,3"
          />
        </label>
      </section>

      <section className="rounded-2xl border border-white/10 bg-black/30 p-4 space-y-3 shadow-[0_16px_50px_rgba(0,0,0,0.45)]">
        <div className="flex items-center justify-between gap-2">
          <div>
            <h2 className="text-lg font-semibold">Branding</h2>
            <p className="text-[12px] text-white/65">Logo e cores aplicadas no dashboard e página pública.</p>
          </div>
          <label className="inline-flex cursor-pointer items-center gap-2 rounded-full border border-white/20 bg-white/5 px-3 py-1.5 text-[12px] text-white hover:bg-white/10">
            <input
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(e) => handleLogoUpload(e.target.files?.[0] ?? null)}
              disabled={brandingUploading}
            />
            {brandingUploading ? "A enviar…" : "Upload logo"}
          </label>
        </div>
        <div className="grid gap-4 md:grid-cols-[1.1fr_0.9fr] md:items-start">
          <div className="flex items-center gap-3 rounded-xl border border-white/10 bg-white/5 p-3">
            <div className="h-16 w-16 overflow-hidden rounded-2xl border border-white/10 bg-white/10">
              {brandingAvatarUrl ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={brandingAvatarUrl} alt="Logo" className="h-full w-full object-cover" />
              ) : (
                <div className="flex h-full w-full items-center justify-center text-sm text-white/70">Logo</div>
              )}
            </div>
            <div className="space-y-1 text-sm text-white/70">
              <p>PNG/JPG/SVG até 2MB. Guardamos logo otimizado.</p>
              <p className="text-[11px] text-white/50">Fica visível no dashboard, listagens e página pública.</p>
            </div>
          </div>
          <div className="space-y-2 rounded-xl border border-white/10 bg-white/5 p-3">
            <div className="grid gap-2 md:grid-cols-2">
              <div className="space-y-1">
                <label className="text-[12px] text-white/70">Cor primária</label>
                <input
                  type="color"
                  value={brandingPrimaryColor || "#6bffff"}
                  onChange={(e) => setBrandingPrimaryColor(e.target.value)}
                  className="h-10 w-full rounded border border-white/20 bg-black/30"
                />
              </div>
              <div className="space-y-1">
                <label className="text-[12px] text-white/70">Cor secundária</label>
                <input
                  type="color"
                  value={brandingSecondaryColor || "#0f172a"}
                  onChange={(e) => setBrandingSecondaryColor(e.target.value)}
                  className="h-10 w-full rounded border border-white/20 bg-black/30"
                />
              </div>
            </div>
            <p className="text-[11px] text-white/55">Escolhe cores para cards e página pública. Clica Guardar para aplicar.</p>
          </div>
        </div>
      </section>

      <section className="rounded-2xl border border-white/10 bg-black/30 p-4 space-y-3 shadow-[0_16px_50px_rgba(0,0,0,0.45)]">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-semibold">Preferências</h2>
            <p className="text-[12px] text-white/65">Idioma, notificações e visibilidade pública.</p>
          </div>
        </div>
          <div className="grid gap-3 md:grid-cols-2">
          <div className="space-y-1">
            <label className="text-[12px] text-white/70">Listagem pública</label>
            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={prefPublicListing}
                onChange={(e) => setPrefPublicListing(e.target.checked)}
                className="h-4 w-4"
              />
              <span className="text-sm text-white/70">Mostrar eventos desta organização em descoberta/listas públicas</span>
            </div>
          </div>
        </div>
        <div className="grid gap-3 md:grid-cols-2">
          <div className="space-y-1">
            <label className="text-[12px] text-white/70">Email de alertas</label>
            <input
              value={alertsEmail}
              onChange={(e) => setAlertsEmail(e.target.value)}
              className="w-full rounded-xl border border-white/15 bg-black/40 px-3 py-2 text-sm outline-none focus:border-[#6BFFFF]"
              placeholder="alerts@exemplo.com"
            />
            <p className="text-[11px] text-white/55">Usado para envios de alertas (vendas/payouts).</p>
          </div>
          <div className="space-y-2 rounded-xl border border-white/10 bg-white/5 p-3 text-sm text-white/80">
            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={alertsSalesEnabled}
                onChange={(e) => setAlertsSalesEnabled(e.target.checked)}
                className="h-4 w-4"
              />
              <span>Alertas de vendas</span>
            </div>
            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={alertsPayoutEnabled}
                onChange={(e) => setAlertsPayoutEnabled(e.target.checked)}
                className="h-4 w-4"
              />
              <span>Alertas de payouts</span>
            </div>
            <p className="text-[11px] text-white/55">Envio de email é simulado (stub) até integrar provider.</p>
          </div>
        </div>
      </section>

      <section className="rounded-2xl border border-red-500/30 bg-red-500/5 p-4 space-y-3 shadow-[0_16px_50px_rgba(0,0,0,0.45)]">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-semibold text-red-100">Zona de perigo</h2>
            <p className="text-[12px] text-red-100/80">
              Apagar a organização marca-a como suspensa e remove memberships. Apenas Owners podem fazê-lo.
            </p>
          </div>
        </div>
        <div className="grid gap-3 md:grid-cols-[1.2fr_0.8fr] md:items-end">
          <div className="space-y-1">
            <label className="text-[12px] text-white/80">Escreve APAGAR para confirmar</label>
            <input
              value={dangerConfirm}
              onChange={(e) => setDangerConfirm(e.target.value)}
              className="w-full rounded-lg border border-red-400/40 bg-black/40 px-3 py-2 text-sm outline-none focus:border-red-200"
              placeholder="APAGAR"
            />
            <p className="text-[11px] text-white/60">
              Ação irreversível (soft delete). Bloqueada se existirem bilhetes vendidos.
            </p>
          </div>
          <div className="flex flex-col gap-2 md:items-end">
            <button
              type="button"
              onClick={handleDeleteOrganization}
              disabled={!isOwner || !dangerReady || dangerLoading}
              className="w-full rounded-full border border-red-400/60 bg-red-500/15 px-4 py-2 text-sm font-semibold text-red-100 shadow hover:bg-red-500/25 disabled:opacity-60 md:w-auto"
            >
              {dangerLoading ? "A apagar…" : "Apagar organização"}
            </button>
            {!isOwner && (
              <p className="text-[11px] text-white/60">Só Owners podem apagar esta organização.</p>
            )}
            {dangerFeedback && (
              <p className="text-[12px] text-white/70">{dangerFeedback}</p>
            )}
          </div>
        </div>
      </section>
    </div>
  );
}
