import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { createSupabaseServer } from "@/lib/supabaseServer";
import { ensureAuthenticated, assertOrganizer } from "@/lib/security";
import { getActiveOrganizerForUser } from "@/lib/organizerContext";
import { FeeMode, RefundFeePayer, ResaleMode } from "@prisma/client";

type TicketInput = {
  name?: string;
  price?: number;
  totalQuantity?: number | null;
};

type Body = {
  title?: string;
  description?: string;
  internalNote?: string | null;
  coverImageUrl?: string | null;
  startsAt?: string;
  endsAt?: string;
  locationName?: string | null;
  locationCity?: string;
  address?: string | null;
  templateType?: string;
  categories?: string[];
  feeMode?: "ON_TOP" | "INCLUDED" | "ADDED";
  refundFeePayer?: RefundFeePayer;
  ticketTypes?: TicketInput[];
  padel?: unknown; // ignorado para já, usamos defaults globais
  visibility?: "PUBLIC" | "PRIVATE";
  publicListingEnabled?: boolean;
};

function parseDate(raw?: string | null) {
  if (!raw) return null;
  const normalized = raw.replace(" ", "T");
  const date = new Date(normalized);
  if (!Number.isNaN(date.getTime())) return date;
  const alt = new Date(`${normalized}:00`);
  if (!Number.isNaN(alt.getTime())) return alt;
  return null;
}

export async function POST(req: NextRequest) {
  try {
    const supabase = await createSupabaseServer();
    const user = await ensureAuthenticated(supabase);

    const body = (await req.json().catch(() => null)) as Body | null;
    if (!body) {
      return NextResponse.json({ ok: false, error: "Body inválido." }, { status: 400 });
    }

    const { organizer } = await getActiveOrganizerForUser(user.id, {
      roles: ["OWNER", "ADMIN"],
    });
    const profile = await prisma.profile.findUnique({ where: { id: user.id } });
    if (!organizer || !profile) {
      return NextResponse.json({ ok: false, error: "Organizador não encontrado." }, { status: 403 });
    }
    assertOrganizer(user, profile, organizer);

    const title = body.title?.trim();
    if (!title) return NextResponse.json({ ok: false, error: "Título é obrigatório." }, { status: 400 });

    const startsAt = parseDate(body.startsAt);
    if (!startsAt) return NextResponse.json({ ok: false, error: "Data de início inválida." }, { status: 400 });
    const endsAtParsed = parseDate(body.endsAt);
    const endsAt = endsAtParsed && endsAtParsed >= startsAt ? endsAtParsed : startsAt;

    const locationCity = body.locationCity?.trim();
    if (!locationCity) return NextResponse.json({ ok: false, error: "Cidade é obrigatória." }, { status: 400 });

    const ticketTypesInput = Array.isArray(body.ticketTypes) ? body.ticketTypes : [];
    const ticketTypes = ticketTypesInput
      .map((t) => {
        const name = t.name?.trim();
        if (!name) return null;
        const price = typeof t.price === "number" && !Number.isNaN(t.price) ? t.price : 0;
        const totalQuantity =
          typeof t.totalQuantity === "number" && t.totalQuantity > 0 ? Math.floor(t.totalQuantity) : null;
        return { name, price, totalQuantity };
      })
      .filter(Boolean) as { name: string; price: number; totalQuantity: number | null }[];

    if (ticketTypes.length === 0) {
      return NextResponse.json({ ok: false, error: "Adiciona pelo menos um tipo de inscrição." }, { status: 400 });
    }

    const feeModeRaw = (body.feeMode ?? "ADDED").toUpperCase();
    const feeMode: FeeMode = feeModeRaw === "INCLUDED" ? FeeMode.INCLUDED : FeeMode.ADDED;
    const refundFeePayer = body.refundFeePayer || organizer.refundFeePayer || RefundFeePayer.CUSTOMER;

    // Defaults do organizer (para CLUBE_PADEL)
    const defaultCourts =
      organizer.padelDefaultCourts && organizer.padelDefaultCourts > 0 ? organizer.padelDefaultCourts : 1;
    const defaultRuleSetId = organizer.padelDefaultRuleSetId ?? null;

    const event = await prisma.event.create({
      data: {
        slug: `${title.toLowerCase().replace(/[^a-z0-9]+/g, "-")}-${Math.random().toString(36).slice(2, 7)}`,
        title,
        description: body.description?.trim() ?? "",
        type: "ORGANIZER_EVENT",
        templateType: "PADEL",
        organizerId: organizer.id,
        ownerUserId: profile.id,
        startsAt,
        endsAt,
        locationName: body.locationName?.trim() || "",
        locationCity,
        address: body.address?.trim() || null,
        isFree: ticketTypes.every((t) => t.price === 0),
        status: "PUBLISHED",
        resaleMode: ResaleMode.ALWAYS,
        coverImageUrl: body.coverImageUrl?.trim() || null,
        feeMode,
        payoutMode: "ORGANIZER",
      },
    });

    // Categorias: força DESPORTO
    await prisma.eventCategory.create({
      data: {
        eventId: event.id,
        category: "DESPORTO",
      },
    });

    await prisma.ticketType.createMany({
      data: ticketTypes.map((t) => ({
        eventId: event.id,
        name: t.name,
        price: Math.round(t.price * 100),
        totalQuantity: t.totalQuantity,
      })),
    });

    // Validar rule set default (se existir)
    if (defaultRuleSetId) {
      const ruleSetValid = await prisma.padelRuleSet.findFirst({
        where: { id: defaultRuleSetId, organizerId: organizer.id },
        select: { id: true },
      });
      if (!ruleSetValid) {
        return NextResponse.json(
          { ok: false, error: "Rule set inválido para este organizador." },
          { status: 400 },
        );
      }
    }

    // Config Padel v2 (defaults globais)
    const formatValue = "GRUPOS_ELIMINATORIAS";
    await prisma.padelTournamentConfig.upsert({
      where: { eventId: event.id },
      create: {
        eventId: event.id,
        organizerId: organizer.id,
        format: formatValue,
        numberOfCourts: defaultCourts,
        ruleSetId: defaultRuleSetId,
        enabledFormats: [],
        padelV2Enabled: true,
        splitDeadlineHours: 48,
        autoCancelUnpaid: true,
        allowCaptainAssume: true,
        defaultPaymentMode: null,
        refundFeePayer,
      },
      update: {
        format: formatValue,
        numberOfCourts: defaultCourts,
        ruleSetId: defaultRuleSetId,
        enabledFormats: [],
        padelV2Enabled: true,
        splitDeadlineHours: 48,
        autoCancelUnpaid: true,
        allowCaptainAssume: true,
        defaultPaymentMode: null,
        refundFeePayer,
      },
    });

    return NextResponse.json({ ok: true, event: { id: event.id, slug: event.slug } }, { status: 201 });
  } catch (err) {
    console.error("[organizador/padel/tournaments/create] error", err);
    return NextResponse.json({ ok: false, error: "Erro ao criar torneio de Padel." }, { status: 500 });
  }
}
