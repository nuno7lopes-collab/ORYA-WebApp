import PurchasesClient from "./purchases-client";

export const metadata = {
  title: "As minhas compras | ORYA",
};

export default function PurchasesPage() {
  return <PurchasesClient />;
}
