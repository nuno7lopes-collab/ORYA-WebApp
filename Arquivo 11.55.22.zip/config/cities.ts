import { PT_CITIES, type PTCity } from "@/lib/constants/ptCities";

export const PORTUGAL_CITIES = PT_CITIES;
export type CityOption = PTCity;
