-- Convites para membros de organização (staff)
CREATE TABLE IF NOT EXISTS "app_v3"."organizer_member_invites" (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organizer_id integer NOT NULL REFERENCES "app_v3"."organizers"(id) ON DELETE CASCADE,
  invited_by_user_id uuid NOT NULL REFERENCES "app_v3"."profiles"(id) ON DELETE CASCADE,
  target_identifier citext NOT NULL,
  target_user_id uuid NULL REFERENCES "app_v3"."profiles"(id) ON DELETE CASCADE,
  role "app_v3"."OrganizerMemberRole" NOT NULL,
  token uuid NOT NULL UNIQUE,
  expires_at timestamptz NOT NULL,
  accepted_at timestamptz NULL,
  declined_at timestamptz NULL,
  cancelled_at timestamptz NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS organizer_member_invites_org_idx ON "app_v3"."organizer_member_invites"(organizer_id);
CREATE INDEX IF NOT EXISTS organizer_member_invites_target_idx ON "app_v3"."organizer_member_invites"(target_user_id);
CREATE INDEX IF NOT EXISTS organizer_member_invites_identifier_idx ON "app_v3"."organizer_member_invites"(target_identifier);
