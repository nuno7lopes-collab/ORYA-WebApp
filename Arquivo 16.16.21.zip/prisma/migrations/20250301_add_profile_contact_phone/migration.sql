ALTER TABLE "app_v3"."profiles"
ADD COLUMN IF NOT EXISTS "contact_phone" TEXT;
