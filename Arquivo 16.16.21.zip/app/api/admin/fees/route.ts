import { NextRequest, NextResponse } from "next/server";
import { createSupabaseServer } from "@/lib/supabaseServer";
import { prisma } from "@/lib/prisma";
import { getPlatformAndStripeFees, setPlatformFees, setStripeBaseFees } from "@/lib/platformSettings";

function rolesContainsAdmin(roles: unknown) {
  if (Array.isArray(roles)) return roles.includes("admin");
  if (typeof roles === "string") {
    try {
      const parsed = JSON.parse(roles);
      if (Array.isArray(parsed) && parsed.includes("admin")) return true;
    } catch {
      return roles.split(",").map((r) => r.trim()).includes("admin");
    }
  }
  return false;
}

async function isAdminUser(userId: string) {
  const supabase = await createSupabaseServer();
  const profileRes = await supabase.from("profiles").select("roles").eq("id", userId).maybeSingle();
  const rolesFromSupabase = profileRes.data?.roles ?? [];

  if (rolesContainsAdmin(rolesFromSupabase)) {
    return true;
  }

  // fallback via prisma (auth schema) in caso de erro/mismatch
  const profileDb = await prisma.profile.findUnique({
    where: { id: userId },
    select: { roles: true },
  });
  const rolesDb = profileDb?.roles ?? [];
  return rolesContainsAdmin(rolesDb);
}

export async function GET(_req: NextRequest) {
  try {
    const supabase = await createSupabaseServer();
    const {
      data: { user },
    } = await supabase.auth.getUser();

    if (!user) {
      return NextResponse.json({ ok: false, error: "UNAUTHENTICATED" }, { status: 401 });
    }

    if (!(await isAdminUser(user.id))) {
      return NextResponse.json({ ok: false, error: "FORBIDDEN" }, { status: 403 });
    }

    const { orya, stripe } = await getPlatformAndStripeFees();

    return NextResponse.json(
      {
        ok: true,
        orya,
        stripe,
      },
      { status: 200 },
    );
  } catch (err) {
    console.error("[admin/fees] unexpected error", err);
    return NextResponse.json({ ok: false, error: "INTERNAL_ERROR" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const supabase = await createSupabaseServer();
    const {
      data: { user },
    } = await supabase.auth.getUser();

    if (!user) {
      return NextResponse.json({ ok: false, error: "UNAUTHENTICATED" }, { status: 401 });
    }

    if (!(await isAdminUser(user.id))) {
      return NextResponse.json({ ok: false, error: "FORBIDDEN" }, { status: 403 });
    }

    const body = await req.json();

    const clamp = (val: number, min: number, max: number) => Math.min(Math.max(val, min), max);
    const platformFeeBpsRaw = Number(body?.platformFeeBps);
    const platformFeeFixedCentsRaw = Number(body?.platformFeeFixedCents);
    const stripeFeeBpsEuRaw = Number(body?.stripeFeeBpsEu);
    const stripeFeeFixedCentsEuRaw = Number(body?.stripeFeeFixedCentsEu);

    const updatesErrors: string[] = [];
    if (body?.platformFeeBps !== undefined && !Number.isFinite(platformFeeBpsRaw)) {
      updatesErrors.push("platformFeeBps inválido");
    }
    if (body?.platformFeeFixedCents !== undefined && !Number.isFinite(platformFeeFixedCentsRaw)) {
      updatesErrors.push("platformFeeFixedCents inválido");
    }
    if (body?.stripeFeeBpsEu !== undefined && !Number.isFinite(stripeFeeBpsEuRaw)) {
      updatesErrors.push("stripeFeeBpsEu inválido");
    }
    if (body?.stripeFeeFixedCentsEu !== undefined && !Number.isFinite(stripeFeeFixedCentsEuRaw)) {
      updatesErrors.push("stripeFeeFixedCentsEu inválido");
    }

    if (updatesErrors.length > 0) {
      return NextResponse.json({ ok: false, error: updatesErrors.join(", ") }, { status: 400 });
    }

    await Promise.all([
      setPlatformFees({
        feeBps: Number.isFinite(platformFeeBpsRaw)
          ? clamp(Math.round(platformFeeBpsRaw), 0, 5000)
          : undefined,
        feeFixedCents: Number.isFinite(platformFeeFixedCentsRaw)
          ? clamp(Math.round(platformFeeFixedCentsRaw), 0, 5000)
          : undefined,
      }),
      setStripeBaseFees({
        feeBps: Number.isFinite(stripeFeeBpsEuRaw)
          ? clamp(Math.round(stripeFeeBpsEuRaw), 0, 5000)
          : undefined,
        feeFixedCents: Number.isFinite(stripeFeeFixedCentsEuRaw)
          ? clamp(Math.round(stripeFeeFixedCentsEuRaw), 0, 5000)
          : undefined,
      }),
    ]);

    const { orya, stripe } = await getPlatformAndStripeFees();

    return NextResponse.json({ ok: true, orya, stripe }, { status: 200 });
  } catch (err) {
    console.error("[admin/fees] unexpected error on POST", err);
    return NextResponse.json({ ok: false, error: "INTERNAL_ERROR" }, { status: 500 });
  }
}
