export const runtime = "nodejs";

import { NextRequest, NextResponse } from "next/server";
import { createSupabaseServer } from "@/lib/supabaseServer";
import { prisma } from "@/lib/prisma";

export async function POST(req: NextRequest) {
  try {
    const supabase = await createSupabaseServer();
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) return NextResponse.json({ ok: false, error: "UNAUTHENTICATED" }, { status: 401 });

    const body = (await req.json().catch(() => null)) as { targetUserId?: string } | null;
    const targetUserId = body?.targetUserId?.trim();
    if (!targetUserId) return NextResponse.json({ ok: false, error: "INVALID_TARGET" }, { status: 400 });
    if (targetUserId === user.id) return NextResponse.json({ ok: false, error: "CANNOT_FOLLOW_SELF" }, { status: 400 });

    try {
      await prisma.follows.create({
        data: {
          follower_id: user.id,
          following_id: targetUserId,
        },
      });
    } catch (err) {
      // ignore unique constraint
    }

    return NextResponse.json({ ok: true }, { status: 200 });
  } catch (err) {
    console.error("[social/follow]", err);
    return NextResponse.json({ ok: false, error: "INTERNAL_ERROR" }, { status: 500 });
  }
}
