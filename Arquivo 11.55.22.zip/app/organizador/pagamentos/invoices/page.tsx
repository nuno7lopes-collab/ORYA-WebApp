import InvoicesClient from "./invoices-client";

export const metadata = {
  title: "Faturação / Invoices | ORYA",
};

export default function InvoicesPage() {
  return <InvoicesClient />;
}
