-- Padel v2: pairings/slots, fees/refund flags, and tournament settings
-- Safe for existing data; legacy untouched.

-- Enums
CREATE TYPE "app_v3"."RefundFeePayer" AS ENUM ('ORGANIZER', 'CUSTOMER');
CREATE TYPE "app_v3"."PadelPaymentMode" AS ENUM ('FULL', 'SPLIT');
CREATE TYPE "app_v3"."PadelPairingStatus" AS ENUM ('INCOMPLETE', 'COMPLETE', 'CANCELLED');
CREATE TYPE "app_v3"."PadelPairingSlotStatus" AS ENUM ('PENDING', 'FILLED', 'CANCELLED');
CREATE TYPE "app_v3"."PadelPairingPaymentStatus" AS ENUM ('UNPAID', 'PAID');
CREATE TYPE "app_v3"."PadelPairingSlotRole" AS ENUM ('CAPTAIN', 'PARTNER');

-- Organizer flag: quem suporta taxas em reembolso
ALTER TABLE "app_v3"."organizers"
  ADD COLUMN "refund_fee_payer" "app_v3"."RefundFeePayer" NOT NULL DEFAULT 'CUSTOMER';

-- Torneio Padel: flag v2, prazos split e fee payer opcional
ALTER TABLE "app_v3"."padel_tournament_configs"
  ADD COLUMN "padel_v2_enabled" BOOLEAN NOT NULL DEFAULT false,
  ADD COLUMN "split_deadline_hours" INTEGER,
  ADD COLUMN "auto_cancel_unpaid" BOOLEAN NOT NULL DEFAULT true,
  ADD COLUMN "allow_captain_assume" BOOLEAN NOT NULL DEFAULT true,
  ADD COLUMN "default_payment_mode" "app_v3"."PadelPaymentMode",
  ADD COLUMN "refund_fee_payer" "app_v3"."RefundFeePayer";

-- Tickets: ligação opcional a pairing e split share
ALTER TABLE "app_v3"."tickets"
  ADD COLUMN "pairing_id" INTEGER,
  ADD COLUMN "padel_split_share_cents" INTEGER,
  ADD COLUMN "padel_pairing_version" INTEGER;

CREATE INDEX "tickets_pairing_id_idx" ON "app_v3"."tickets"("pairing_id");

-- Pairings (duplas)
CREATE TABLE "app_v3"."padel_pairings" (
  "id" SERIAL PRIMARY KEY,
  "event_id" INTEGER NOT NULL,
  "organizer_id" INTEGER NOT NULL,
  "category_id" INTEGER,
  "payment_mode" "app_v3"."PadelPaymentMode" NOT NULL,
  "pairing_status" "app_v3"."PadelPairingStatus" NOT NULL DEFAULT 'INCOMPLETE',
  "created_by_user_id" UUID,
  "created_by_ticket_id" TEXT,
  "invite_token" TEXT UNIQUE,
  "invite_expires_at" TIMESTAMPTZ,
  "locked_until" TIMESTAMPTZ,
  "is_public_open" BOOLEAN NOT NULL DEFAULT false,
  "created_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  "updated_at" TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX "padel_pairings_event_id_idx" ON "app_v3"."padel_pairings"("event_id");
CREATE INDEX "padel_pairings_organizer_id_idx" ON "app_v3"."padel_pairings"("organizer_id");
CREATE INDEX "padel_pairings_category_id_idx" ON "app_v3"."padel_pairings"("category_id");

ALTER TABLE "app_v3"."padel_pairings"
  ADD CONSTRAINT "padel_pairings_event_id_fkey" FOREIGN KEY ("event_id") REFERENCES "app_v3"."events"("id") ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT "padel_pairings_organizer_id_fkey" FOREIGN KEY ("organizer_id") REFERENCES "app_v3"."organizers"("id") ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT "padel_pairings_category_id_fkey" FOREIGN KEY ("category_id") REFERENCES "app_v3"."padel_categories"("id") ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT "padel_pairings_created_ticket_fkey" FOREIGN KEY ("created_by_ticket_id") REFERENCES "app_v3"."tickets"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- Slots por pairing
CREATE TABLE "app_v3"."padel_pairing_slots" (
  "id" SERIAL PRIMARY KEY,
  "pairing_id" INTEGER NOT NULL,
  "ticket_id" TEXT,
  "profile_id" UUID,
  "slot_role" "app_v3"."PadelPairingSlotRole" NOT NULL,
  "slot_status" "app_v3"."PadelPairingSlotStatus" NOT NULL DEFAULT 'PENDING',
  "payment_status" "app_v3"."PadelPairingPaymentStatus" NOT NULL DEFAULT 'UNPAID',
  "invited_contact" TEXT,
  "is_public_open" BOOLEAN NOT NULL DEFAULT false,
  "created_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  "updated_at" TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT "padel_pairing_slots_ticket_id_key" UNIQUE ("ticket_id")
);

CREATE INDEX "padel_pairing_slots_pairing_id_idx" ON "app_v3"."padel_pairing_slots"("pairing_id");
CREATE INDEX "padel_pairing_slots_profile_id_idx" ON "app_v3"."padel_pairing_slots"("profile_id");

ALTER TABLE "app_v3"."padel_pairing_slots"
  ADD CONSTRAINT "padel_pairing_slots_pairing_id_fkey" FOREIGN KEY ("pairing_id") REFERENCES "app_v3"."padel_pairings"("id") ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT "padel_pairing_slots_ticket_id_fkey" FOREIGN KEY ("ticket_id") REFERENCES "app_v3"."tickets"("id") ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT "padel_pairing_slots_profile_id_fkey" FOREIGN KEY ("profile_id") REFERENCES "app_v3"."profiles"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- Ligação ticket -> pairing (FK)
ALTER TABLE "app_v3"."tickets"
  ADD CONSTRAINT "tickets_pairing_id_fkey" FOREIGN KEY ("pairing_id") REFERENCES "app_v3"."padel_pairings"("id") ON DELETE SET NULL ON UPDATE CASCADE;
