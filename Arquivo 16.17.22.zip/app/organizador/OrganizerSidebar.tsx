"use client";

import Link from "next/link";
import { usePathname, useSearchParams } from "next/navigation";
import { useEffect, useMemo, useState } from "react";

const baseTabHref = (tab: string) => `/organizador?tab=${tab}`;

type Props = {
  organizerName?: string | null;
  organizerAvatarUrl?: string | null;
};

export function OrganizerSidebar({ organizerName, organizerAvatarUrl }: Props) {
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const tabParam = searchParams?.get("tab") || "overview";

  const categoriesActive = useMemo(
    () =>
      pathname.startsWith("/organizador/categorias") ||
      (pathname === "/organizador" && tabParam === "events" && searchParams?.get("view") === "categories"),
    [pathname, tabParam, searchParams],
  );

  const [openCategories, setOpenCategories] = useState<boolean>(categoriesActive);

  useEffect(() => {
    if (categoriesActive) setOpenCategories(true);
  }, [categoriesActive]);

  const linkClass = (active: boolean) =>
    `flex items-center justify-between rounded-xl px-3 py-2 transition ${
      active ? "bg-white/10 text-white font-semibold border border-white/20" : "hover:bg-white/10"
    }`;

  return (
    <aside className="hidden lg:flex w-60 shrink-0 flex-col gap-2 border-r border-white/10 bg-black/40 backdrop-blur-xl px-4 py-6 text-[13px] text-white/80 shadow-[0_18px_60px_rgba(0,0,0,0.55)] sticky top-0 h-screen overflow-y-auto">
      <div className="flex items-center gap-2 px-2">
        <div className="h-9 w-9 rounded-2xl bg-gradient-to-br from-[#0f172a] via-[#111827] to-[#0b1224] flex items-center justify-center text-xs font-black tracking-[0.2em] text-[#6BFFFF] shadow-[0_0_14px_rgba(107,255,255,0.3)] overflow-hidden border border-white/10">
          {organizerAvatarUrl ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={organizerAvatarUrl} alt={organizerName || "Organizador"} className="h-full w-full object-cover" />
          ) : (
            "OY"
          )}
        </div>
        <div>
          <p className="text-[10px] uppercase tracking-[0.25em] text-white/50">Dashboard</p>
          <p className="text-sm font-semibold text-white">{organizerName || "Organizador"}</p>
        </div>
      </div>
      <nav className="mt-4 space-y-1">
        <Link href={baseTabHref("overview")} className={linkClass(pathname === "/organizador" ? tabParam === "overview" : pathname === "/organizador")}>
          <span>Resumo</span>
        </Link>
        <Link
          href={baseTabHref("events")}
          className={linkClass(
            (pathname === "/organizador" && tabParam === "events") || pathname.startsWith("/organizador/eventos"),
          )}
        >
          <span>Eventos</span>
        </Link>
        <Link
          href="/organizador/eventos/novo"
          className={linkClass(pathname.startsWith("/organizador/eventos/novo") || (pathname.includes("/organizador/eventos/") && pathname.endsWith("/edit")))}
        >
          <span>Criar evento</span>
        </Link>
        <Link
          href={baseTabHref("sales")}
          className={linkClass((pathname === "/organizador" && tabParam === "sales") || pathname.startsWith("/organizador/estatisticas"))}
        >
          <span>Bilhetes & Vendas</span>
        </Link>
        <Link
          href={baseTabHref("finance")}
          className={linkClass((pathname === "/organizador" && tabParam === "finance") || pathname.startsWith("/organizador/pagamentos"))}
        >
          <span>Finanças & Payouts</span>
        </Link>
        <Link
          href={baseTabHref("marketing")}
          className={linkClass((pathname === "/organizador" && tabParam === "marketing") || pathname.startsWith("/organizador/promo"))}
        >
          <span>Marketing</span>
        </Link>
        <Link
          href="/organizador/staff"
          className={linkClass(pathname.startsWith("/organizador/staff"))}
        >
          <span>Staff</span>
        </Link>

        <button
          type="button"
          onClick={() => setOpenCategories((prev) => !prev)}
          className={`${linkClass(categoriesActive || openCategories)} w-full`}
        >
          <span className="flex-1 text-left">Categorias</span>
          <span className="text-[11px] text-white/70 leading-none">{openCategories ? "▾" : "▸"}</span>
        </button>
        {openCategories && (
          <div className="pl-3 space-y-1">
            <Link
              href="/organizador/categorias/padel"
              className={linkClass(pathname.startsWith("/organizador/categorias/padel"))}
            >
              <span>Padel</span>
            </Link>
          </div>
        )}

        <Link
          href="/organizador/settings"
          className={linkClass(pathname.startsWith("/organizador/settings"))}
        >
          <span>Definições</span>
        </Link>
      </nav>
    </aside>
  );
}
