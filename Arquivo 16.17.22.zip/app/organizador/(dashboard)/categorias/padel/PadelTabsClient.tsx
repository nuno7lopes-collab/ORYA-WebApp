"use client";

import { useState } from "react";
import Link from "next/link";

type Player = {
  id: number;
  fullName: string;
  email: string | null;
  phone: string | null;
  gender: string | null;
  level: string | null;
  isActive: boolean;
  createdAt: string | Date;
};

type RuleSet = {
  id: number;
  name: string;
  tieBreakRules: string[];
  pointsTable: Record<string, number>;
  enabledFormats: string[];
  season: string | null;
  year: number | null;
};

type RankingItem = {
  position: number;
  points: number;
  player: { id: number; fullName: string; level: string | null };
};

type Props = {
  organizerId: number;
  initialPlayers: Player[];
  initialRuleSets: RuleSet[];
  initialRankings: RankingItem[];
};

const PAD_TAB_CLASS =
  "rounded-full border border-white/10 bg-white/5 px-3 py-1 text-[12px] text-white/75 hover:border-white/20";

export default function PadelTabsClient({ organizerId, initialPlayers, initialRuleSets, initialRankings }: Props) {
  const [activeTab, setActiveTab] = useState<"players" | "rankings" | "rules">("players");
  const [players, setPlayers] = useState<Player[]>(initialPlayers);
  const [ruleSets, setRuleSets] = useState<RuleSet[]>(initialRuleSets);
  const [rankings, setRankings] = useState<RankingItem[]>(initialRankings);
  const [playerForm, setPlayerForm] = useState({
    fullName: "",
    email: "",
    phone: "",
    gender: "",
    level: "",
  });
  const [ruleForm, setRuleForm] = useState({
    name: "",
    win: 3,
    loss: 0,
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const addPlayer = async () => {
    if (!playerForm.fullName.trim()) {
      setError("Nome é obrigatório.");
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/padel/players", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          fullName: playerForm.fullName,
          email: playerForm.email || null,
          phone: playerForm.phone || null,
          gender: playerForm.gender || null,
          level: playerForm.level || null,
        }),
      });
      const json = await res.json();
      if (!res.ok || !json?.ok) {
        setError(json?.error || "Erro ao gravar jogador.");
      } else {
        setPlayers((prev) => [json.player, ...prev]);
        setPlayerForm({ fullName: "", email: "", phone: "", gender: "", level: "" });
      }
    } catch (err) {
      console.error("[PadelTabsClient] addPlayer", err);
      setError("Erro inesperado ao gravar jogador.");
    } finally {
      setLoading(false);
    }
  };

  const addRuleSet = async () => {
    if (!ruleForm.name.trim()) {
      setError("Nome do rule set é obrigatório.");
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/padel/rulesets", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: ruleForm.name,
          tieBreakRules: ["HEAD_TO_HEAD", "POINTS"],
          pointsTable: { WIN: Number(ruleForm.win), LOSS: Number(ruleForm.loss) },
          enabledFormats: ["TODOS_CONTRA_TODOS", "QUADRO_ELIMINATORIO"],
        }),
      });
      const json = await res.json();
      if (!res.ok || !json?.ok) {
        setError(json?.error || "Erro ao gravar regras.");
      } else {
        setRuleSets((prev) => [json.ruleSet, ...prev]);
        setRuleForm({ name: "", win: 3, loss: 0 });
      }
    } catch (err) {
      console.error("[PadelTabsClient] addRuleSet", err);
      setError("Erro inesperado ao gravar regras.");
    } finally {
      setLoading(false);
    }
  };

  const refreshRankings = async () => {
    const res = await fetch(`/api/padel/rankings?organizerId=${organizerId}`);
    const json = await res.json();
    if (!res.ok || !json?.ok) {
      setError(json?.error || "Erro ao carregar ranking.");
      return;
    }
    setRankings(json.items);
  };

  return (
    <div>
      <div className="flex flex-wrap gap-2 border-b border-white/10 pb-3">
        <button className={PAD_TAB_CLASS} onClick={() => setActiveTab("players")}>
          Jogadores
        </button>
        <button className={PAD_TAB_CLASS} onClick={() => setActiveTab("rankings")}>
          Rankings
        </button>
        <button className={PAD_TAB_CLASS} onClick={() => setActiveTab("rules")}>
          Formatos &amp; Regras
        </button>
      </div>

      {error && <p className="mt-2 text-[12px] text-red-300">{error}</p>}

      {activeTab === "players" && (
        <div className="grid gap-4 pt-4 md:grid-cols-[1.1fr_1fr]">
          <div className="space-y-3 rounded-2xl border border-white/10 bg-white/[0.04] p-4">
            <p className="text-[12px] uppercase tracking-[0.2em] text-white/60">Adicionar jogador</p>
            <div className="grid gap-2 sm:grid-cols-2">
              <input
                value={playerForm.fullName}
                onChange={(e) => setPlayerForm((p) => ({ ...p, fullName: e.target.value }))}
                placeholder="Nome"
                className="rounded-lg border border-white/15 bg-black/30 px-3 py-2 text-sm outline-none"
              />
              <input
                value={playerForm.email}
                onChange={(e) => setPlayerForm((p) => ({ ...p, email: e.target.value }))}
                placeholder="Email"
                className="rounded-lg border border-white/15 bg-black/30 px-3 py-2 text-sm outline-none"
              />
              <input
                value={playerForm.phone}
                onChange={(e) => setPlayerForm((p) => ({ ...p, phone: e.target.value }))}
                placeholder="Telefone"
                className="rounded-lg border border-white/15 bg-black/30 px-3 py-2 text-sm outline-none"
              />
              <input
                value={playerForm.level}
                onChange={(e) => setPlayerForm((p) => ({ ...p, level: e.target.value }))}
                placeholder="Nível (ex: M3)"
                className="rounded-lg border border-white/15 bg-black/30 px-3 py-2 text-sm outline-none"
              />
            </div>
            <div className="flex gap-2">
              <button
                onClick={addPlayer}
                disabled={loading}
                className="rounded-full bg-white/10 px-4 py-2 text-sm text-white hover:bg-white/15 disabled:opacity-50"
              >
                {loading ? "A guardar..." : "Guardar jogador"}
              </button>
              <Link
                href="/organizador/eventos/novo?preset=PADEL"
                className="rounded-full border border-white/20 px-3 py-2 text-[12px] text-white/80 hover:bg-white/10"
              >
                Criar torneio PADEL
              </Link>
            </div>
          </div>

          <div className="space-y-3 rounded-2xl border border-white/10 bg-white/[0.04] p-4">
            <p className="text-[12px] uppercase tracking-[0.2em] text-white/60">Roster</p>
            <div className="max-h-72 overflow-auto space-y-1 text-[13px]">
              {players.length === 0 && <p className="text-white/60">Ainda sem jogadores.</p>}
              {players.map((p) => (
                <div
                  key={p.id}
                  className="flex items-center justify-between rounded-xl border border-white/10 bg-black/30 px-3 py-2"
                >
                  <div>
                    <p className="font-semibold text-white">{p.fullName}</p>
                    <p className="text-[11px] text-white/60">
                      {p.level || "Nível?"} · {p.email || "sem email"}
                    </p>
                  </div>
                  <span className="rounded-full border border-white/15 bg-white/10 px-2 py-[2px] text-[10px] text-white/70">
                    {p.isActive ? "Ativo" : "Inativo"}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {activeTab === "rules" && (
        <div className="grid gap-4 pt-4 md:grid-cols-[1fr_1fr]">
          <div className="space-y-3 rounded-2xl border border-white/10 bg-white/[0.04] p-4">
            <p className="text-[12px] uppercase tracking-[0.2em] text-white/60">Rule set</p>
            <input
              value={ruleForm.name}
              onChange={(e) => setRuleForm((p) => ({ ...p, name: e.target.value }))}
              placeholder="Nome do rule set"
              className="w-full rounded-lg border border-white/15 bg-black/30 px-3 py-2 text-sm outline-none"
            />
            <div className="grid grid-cols-2 gap-2">
              <label className="text-[12px] text-white/60">
                Pontos vitória
                <input
                  type="number"
                  value={ruleForm.win}
                  onChange={(e) => setRuleForm((p) => ({ ...p, win: Number(e.target.value) }))}
                  className="mt-1 w-full rounded-lg border border-white/15 bg-black/30 px-3 py-2 text-sm outline-none"
                />
              </label>
              <label className="text-[12px] text-white/60">
                Pontos derrota
                <input
                  type="number"
                  value={ruleForm.loss}
                  onChange={(e) => setRuleForm((p) => ({ ...p, loss: Number(e.target.value) }))}
                  className="mt-1 w-full rounded-lg border border-white/15 bg-black/30 px-3 py-2 text-sm outline-none"
                />
              </label>
            </div>
            <button
              onClick={addRuleSet}
              disabled={loading}
              className="rounded-full bg-white/10 px-4 py-2 text-sm text-white hover:bg-white/15 disabled:opacity-50"
            >
              {loading ? "A guardar..." : "Guardar regras"}
            </button>
          </div>

          <div className="space-y-3 rounded-2xl border border-white/10 bg-white/[0.04] p-4">
            <p className="text-[12px] uppercase tracking-[0.2em] text-white/60">Rule sets</p>
            <div className="space-y-2 max-h-80 overflow-auto">
              {ruleSets.length === 0 && <p className="text-white/60 text-sm">Sem rule sets ainda.</p>}
              {ruleSets.map((r) => (
                <div key={r.id} className="rounded-xl border border-white/10 bg-black/30 p-3 text-sm">
                  <div className="flex items-center justify-between">
                    <p className="font-semibold">{r.name}</p>
                    <span className="text-[11px] text-white/60">
                      {r.enabledFormats?.join(", ") || "Formatos padrão"}
                    </span>
                  </div>
                  <p className="text-[12px] text-white/60">
                    Pontos: {r.pointsTable ? JSON.stringify(r.pointsTable) : "N/A"}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {activeTab === "rankings" && (
        <div className="pt-4 rounded-2xl border border-white/10 bg-white/[0.04] p-4 text-sm text-white/70 space-y-3">
          <div className="flex items-center justify-between">
            <p className="text-[12px] uppercase tracking-[0.2em] text-white/60">Ranking do clube</p>
            <button
              onClick={refreshRankings}
              className="rounded-full border border-white/20 px-3 py-1 text-[12px] text-white/80 hover:bg-white/10"
            >
              Atualizar
            </button>
          </div>
          <div className="space-y-2">
            {rankings.length === 0 && <p className="text-white/60 text-sm">Sem entradas de ranking ainda.</p>}
            {rankings.map((r) => (
              <div key={r.player.id} className="flex items-center justify-between rounded-lg border border-white/10 bg-black/30 px-3 py-2">
                <div className="flex items-center gap-2">
                  <span className="text-[12px] text-white/60">#{r.position}</span>
                  <div>
                    <p className="font-semibold text-white">{r.player.fullName}</p>
                    <p className="text-[11px] text-white/60">{r.player.level || "Nível?"}</p>
                  </div>
                </div>
                <span className="text-[12px] font-semibold text-[#6BFFFF]">{r.points} pts</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
