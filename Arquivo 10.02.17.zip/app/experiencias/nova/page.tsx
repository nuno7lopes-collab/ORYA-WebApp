"use client";

import { useEffect } from "react";
import { redirect } from "next/navigation";
import { useUser } from "@/app/hooks/useUser";
import { useAuthModal } from "@/app/components/autenticação/AuthModalContext";

export default function NovaExperienciaPage() {
  const { user, isLoading } = useUser();
  const { openModal } = useAuthModal();

  useEffect(() => {
    if (isLoading) return;
    if (!user) {
      openModal({ mode: "login", redirectTo: "/experiencias" });
    }
    redirect("/experiencias");
  }, [isLoading, user, openModal]);

  return null;
}
