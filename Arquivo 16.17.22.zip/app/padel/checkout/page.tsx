"use client";
export const dynamic = "force-dynamic";

import { Suspense, useEffect, useMemo, useState } from "react";
import { useSearchParams, useRouter } from "next/navigation";
import { loadStripe } from "@stripe/stripe-js";
import { Elements, PaymentElement, useElements, useStripe } from "@stripe/react-stripe-js";

type TicketTypeLite = { id: number; name: string; price: number; currency: string };

function formatPrice(cents: number, currency: string) {
  return new Intl.NumberFormat("pt-PT", {
    style: "currency",
    currency: currency || "EUR",
    minimumFractionDigits: 2,
  }).format(cents / 100);
}

function PadelCheckoutContent() {
  const params = useSearchParams();
  const token = params.get("token");
  const pairingIdParam = params.get("pairingId");
  const pairingId = pairingIdParam ? Number(pairingIdParam) : null;
  const modeParam = params.get("mode"); // "full" => capitão pagou dupla inteira

  const [ticketTypes, setTicketTypes] = useState<TicketTypeLite[]>([]);
  const [ticketTypeId, setTicketTypeId] = useState<number | null>(null);
  const [clientSecret, setClientSecret] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [resolvedPairingId, setResolvedPairingId] = useState<number | null>(pairingId);
  const [pairingMode, setPairingMode] = useState<"FULL" | "SPLIT" | null>(null);

  const stripePromise = useMemo(() => {
    const key = process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY;
    return key ? loadStripe(key) : null;
  }, []);

  const selectedTicket = ticketTypes.find((t) => t.id === ticketTypeId) ?? null;
  const quantity = pairingMode === "FULL" || modeParam === "full" ? 2 : 1;
  // subtotal calculado apenas para exibir (imediato no UI)

  useEffect(() => {
    async function fetchPreview() {
      if (!token && !pairingId) return;
      setLoading(true);
      setError(null);
      try {
        // Se tivermos token de convite, usar endpoint de claim preview
        if (token) {
          const res = await fetch(`/api/padel/pairings/claim/${token}`, { method: "GET" });
          const json = await res.json();
          if (!res.ok || !json?.ok) {
            throw new Error(json?.error || "Erro a carregar convite");
          }
          setResolvedPairingId(json.pairing?.id ?? null);
          setPairingMode(json.pairing?.paymentMode ?? null);
          setTicketTypes(json.ticketTypes ?? []);
          if (json.ticketTypes?.[0]) setTicketTypeId(json.ticketTypes[0].id);
        } else if (pairingId) {
          const res = await fetch(`/api/padel/pairings?id=${pairingId}`);
          const json = await res.json();
          if (!res.ok || !json?.ok) {
            throw new Error(json?.error || "Erro a carregar pairing");
          }
          setResolvedPairingId(pairingId);
          setPairingMode(json.pairing?.paymentMode ?? null);
          setTicketTypes(json.ticketTypes ?? []);
          if (json.ticketTypes?.[0]) setTicketTypeId(json.ticketTypes[0].id);
        }
      } catch (err) {
        console.error("[PadelCheckout] preview error", err);
        setError(err instanceof Error ? err.message : "Erro ao carregar");
      } finally {
        setLoading(false);
      }
    }
    fetchPreview();
  }, [token, pairingId]);

  useEffect(() => {
    async function createIntent() {
      if (!ticketTypeId || (!token && !resolvedPairingId)) return;
      setLoading(true);
      setError(null);
      try {
        const res = await fetch(`/api/padel/pairings/${resolvedPairingId ?? ""}/checkout`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            ticketTypeId,
            inviteToken: token ?? undefined,
          }),
        });
        const json = await res.json();
        if (!res.ok || !json?.ok || !json?.clientSecret) {
          throw new Error(json?.error || "Erro ao criar pagamento");
        }
        setClientSecret(json.clientSecret);
      } catch (err) {
        console.error("[PadelCheckout] intent error", err);
        setError(err instanceof Error ? err.message : "Erro ao criar pagamento");
      } finally {
        setLoading(false);
      }
    }
    createIntent();
  }, [ticketTypeId, token, resolvedPairingId]);

  if (!stripePromise) {
    return <div className="p-6 text-white">Configuração Stripe em falta.</div>;
  }

  return (
    <div className="min-h-screen orya-body-bg text-white px-4 py-10 flex justify-center">
      <div className="w-full max-w-xl space-y-6">
        <div>
          <h1 className="text-2xl font-semibold">Pagamento Padel</h1>
          <p className="text-white/70 text-sm">Completa o pagamento do teu lugar ou dupla.</p>
        </div>

        {error && <p className="rounded-xl border border-red-400/40 bg-red-900/30 p-3 text-sm text-red-100">{error}</p>}

        {selectedTicket && (
          <div className="rounded-2xl border border-white/10 bg-white/5 p-4 space-y-2">
            <p className="text-sm font-semibold">Resumo</p>
            <div className="flex justify-between text-sm">
              <span>{selectedTicket.name} × {quantity}</span>
              <span>{formatPrice(selectedTicket.price * quantity, selectedTicket.currency)}</span>
            </div>
            <div className="flex justify-between text-sm text-white/70">
              <span>Taxas de serviço</span>
              <span>Incluídas no preço</span>
            </div>
            <div className="flex justify-between text-base font-semibold pt-1 border-t border-white/10">
              <span>Total</span>
              <span>{formatPrice(selectedTicket.price * quantity, selectedTicket.currency)}</span>
            </div>
          </div>
        )}

        <div className="space-y-2">
          <label className="text-sm text-white/70">Bilhete</label>
          <select
            value={ticketTypeId ?? ""}
            onChange={(e) => setTicketTypeId(e.target.value ? Number(e.target.value) : null)}
            className="w-full rounded-xl border border-white/15 bg-black/30 px-3 py-2 text-white"
            disabled={loading}
          >
            {ticketTypes.map((tt) => (
              <option key={tt.id} value={tt.id}>
                {tt.name} — {formatPrice(tt.price, tt.currency)}
              </option>
            ))}
          </select>
        </div>

        {clientSecret ? (
          <Elements stripe={stripePromise} options={{ clientSecret, appearance: { theme: "night" } }}>
            <PaymentForm />
          </Elements>
        ) : (
          <p className="text-sm text-white/60">A preparar checkout…</p>
        )}
      </div>
    </div>
  );
}

export default function PadelCheckoutPage() {
  return (
    <Suspense fallback={<div className="min-h-screen orya-body-bg text-white p-6">A carregar checkout…</div>}>
      <PadelCheckoutContent />
    </Suspense>
  );
}

function PaymentForm() {
  const stripe = useStripe();
  const elements = useElements();
  const router = useRouter();
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!stripe || !elements) return;
    setSubmitting(true);
    const { error } = await stripe.confirmPayment({
      elements,
      confirmParams: {},
      redirect: "if_required",
    });
    if (error) {
      alert(error.message || "Pagamento falhou");
      setSubmitting(false);
      return;
    }
    alert("Pagamento concluído");
    router.replace("/organizador?tab=overview");
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <PaymentElement />
      <button
        type="submit"
        disabled={submitting || !stripe}
        className="w-full rounded-full bg-gradient-to-r from-[#FF00C8] via-[#6BFFFF] to-[#1646F5] px-4 py-2 font-semibold text-black shadow hover:brightness-110 disabled:opacity-60"
      >
        {submitting ? "A processar..." : "Pagar"}
      </button>
    </form>
  );
}
