// app/api/upload/route.ts
import { NextRequest, NextResponse } from "next/server";
import crypto from "crypto";
import { createClient } from "@supabase/supabase-js";
import { env } from "@/lib/env";

export const runtime = "nodejs"; // precisamos de Node APIs
export const dynamic = "force-dynamic";

const BUCKET_NAME = "event-covers";

const supabase = createClient(env.supabaseUrl, env.serviceRoleKey, {
  auth: { autoRefreshToken: false, persistSession: false },
});

async function ensureBucket() {
  const { data, error } = await supabase.storage.listBuckets();
  if (error) throw error;

  const bucket = data?.find((b) => b.name === BUCKET_NAME);
  if (bucket) {
    if (!bucket.public) {
      const { error: updateErr } = await supabase.storage.updateBucket(BUCKET_NAME, {
        public: true,
      });
      if (updateErr) throw updateErr;
    }
    return;
  }

  {
    const { error: createErr } = await supabase.storage.createBucket(BUCKET_NAME, {
      public: true,
    });
    if (createErr && !createErr.message?.includes("already exists")) {
      throw createErr;
    }
  }
}

export async function POST(req: NextRequest) {
  try {
    const formData = await req.formData();
    const file = formData.get("file") as File | null;

    if (!file) {
      return NextResponse.json({ error: "Nenhum ficheiro enviado." }, { status: 400 });
    }

    if (!file.type.startsWith("image/")) {
      return NextResponse.json({ error: "Só são permitidas imagens." }, { status: 400 });
    }

    const bytes = await file.arrayBuffer();
    const buffer = Buffer.from(bytes);

    const ext = file.type.split("/")[1] || "png";
    const randomName = crypto.randomBytes(16).toString("hex");
    const filename = `${Date.now()}-${randomName}.${ext}`;
    const objectPath = `covers/${filename}`;

    await ensureBucket();

    const { error: uploadError } = await supabase.storage.from(BUCKET_NAME).upload(objectPath, buffer, {
      cacheControl: "31536000",
      contentType: file.type,
      upsert: false,
    });

    if (uploadError) {
      console.error("[upload] supabase upload error", uploadError);
      return NextResponse.json({ error: "Falha ao guardar a imagem." }, { status: 500 });
    }

    const { data: publicUrlData } = supabase.storage.from(BUCKET_NAME).getPublicUrl(objectPath);
    const publicUrl = publicUrlData?.publicUrl;

    if (!publicUrl) {
      return NextResponse.json({ error: "Não foi possível gerar o URL da imagem." }, { status: 500 });
    }

    return NextResponse.json({ url: publicUrl, path: objectPath }, { status: 201 });
  } catch (err) {
    console.error("[POST /api/upload]", err);
    return NextResponse.json({ error: "Erro ao fazer upload da imagem." }, { status: 500 });
  }
}
