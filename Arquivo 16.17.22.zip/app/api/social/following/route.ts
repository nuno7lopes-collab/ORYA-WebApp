export const runtime = "nodejs";

import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET(req: NextRequest) {
  const userId = req.nextUrl.searchParams.get("userId");
  if (!userId) return NextResponse.json({ ok: false, error: "INVALID_USER" }, { status: 400 });

  const limit = Math.min(Number(req.nextUrl.searchParams.get("limit") || 20), 50);
  const offset = Number(req.nextUrl.searchParams.get("offset") || 0);

  const [items, total] = await Promise.all([
    prisma.follows.findMany({
      where: { follower_id: userId },
      include: {
        following: { select: { id: true, username: true, fullName: true, avatarUrl: true } },
      },
      orderBy: { created_at: "desc" },
      skip: offset,
      take: limit,
    }),
    prisma.follows.count({ where: { follower_id: userId } }),
  ]);

  return NextResponse.json(
    {
      ok: true,
      total,
      items: items
        .map((f) => f.following)
        .filter(Boolean)
        .map((p) => ({
          id: p.id,
          username: p.username,
          fullName: p.fullName,
          avatarUrl: p.avatarUrl,
        })),
    },
    { status: 200 },
  );
}
