"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export default function OrganizerBecomePage() {
  const router = useRouter();
  const [businessName, setBusinessName] = useState("");
  const [entityType, setEntityType] = useState("");
  const [city, setCity] = useState("");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleCreate = async () => {
    if (!businessName.trim() || !entityType.trim() || !city.trim()) {
      setError("Preenche nome, tipo de entidade e cidade.");
      return;
    }
    setSaving(true);
    setError(null);
    try {
      const res = await fetch("/api/organizador/organizations", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          businessName: businessName.trim(),
          entityType: entityType.trim(),
          city: city.trim(),
          displayName: businessName.trim(),
        }),
      });
      const json = await res.json().catch(() => null);
      if (!res.ok || json?.ok === false) {
        setError(json?.error || "Não foi possível criar a organização.");
      } else {
        const newId = json?.organizer?.id;
        if (newId) {
          await fetch("/api/organizador/organizations/switch", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ organizerId: newId }),
          });
        }
        router.push("/organizador?tab=overview");
      }
    } catch (err) {
      console.error("[organizador/become]", err);
      setError("Erro inesperado. Tenta novamente.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="orya-body-bg min-h-screen text-white flex items-center justify-center px-4">
      <div className="w-full max-w-xl rounded-3xl border border-white/10 bg-black/50 p-6 shadow-[0_18px_60px_rgba(0,0,0,0.55)] space-y-4">
        <p className="text-[11px] uppercase tracking-[0.3em] text-white/60">Organizador</p>
        <h1 className="text-2xl font-semibold">Criar nova organização</h1>
        <p className="text-sm text-white/65">
          Define o nome, tipo de entidade e cidade base para começares a gerir eventos.
        </p>

        <div className="space-y-2">
          <label className="text-[12px] text-white/70">Nome da organização</label>
          <input
            value={businessName}
            onChange={(e) => setBusinessName(e.target.value)}
            className="w-full rounded-xl border border-white/15 bg-black/40 px-3 py-2 text-sm outline-none focus:border-[#6BFFFF]"
            placeholder="Ex.: ORYA TEAM, Casa Guedes"
          />
        </div>
        <div className="space-y-2">
          <label className="text-[12px] text-white/70">Tipo de entidade</label>
          <select
            value={entityType}
            onChange={(e) => setEntityType(e.target.value)}
            className="w-full rounded-xl border border-white/15 bg-black/40 px-3 py-2 text-sm outline-none focus:border-[#6BFFFF]"
          >
            <option value="">Seleciona</option>
            <option value="PESSOA_SINGULAR">Pessoa singular</option>
            <option value="EMPRESA">Empresa</option>
            <option value="ASSOCIACAO">Associação</option>
          </select>
        </div>
        <div className="space-y-2">
          <label className="text-[12px] text-white/70">Cidade base</label>
          <input
            value={city}
            onChange={(e) => setCity(e.target.value)}
            className="w-full rounded-xl border border-white/15 bg-black/40 px-3 py-2 text-sm outline-none focus:border-[#6BFFFF]"
            placeholder="Lisboa, Porto..."
          />
        </div>

        {error && <p className="text-sm text-red-300">{error}</p>}

        <button
          type="button"
          onClick={handleCreate}
          disabled={saving}
          className="w-full rounded-full bg-gradient-to-r from-[#FF00C8] via-[#6BFFFF] to-[#1646F5] px-4 py-2 text-sm font-semibold text-black shadow disabled:opacity-60"
        >
          {saving ? "A criar…" : "Criar organização"}
        </button>
      </div>
    </div>
  );
}
