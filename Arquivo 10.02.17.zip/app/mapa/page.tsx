export const dynamic = "force-dynamic";

export default function MapaPage() {
  return (
    <main className="orya-body-bg min-h-screen text-white">
      <section className="max-w-5xl mx-auto px-4 py-10 space-y-4">
        <h1 className="text-2xl font-semibold">Mapa</h1>
        <p className="text-sm text-white/70">
          Em breve vais poder explorar eventos diretamente no mapa. Continua a navegar em
          &quot;Explorar&quot; enquanto preparamos esta vista.
        </p>
      </section>
    </main>
  );
}
