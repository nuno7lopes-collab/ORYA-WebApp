"use client";

import { useRouter } from "next/navigation";

type Props = {
  pathname: string;
  isSearchOpen: boolean;
  onOpenSearch: () => void;
  onCloseSearch: () => void;
};

export default function MobileBottomNav({ pathname, isSearchOpen, onOpenSearch, onCloseSearch }: Props) {
  const router = useRouter();

  return (
    <nav
      className="fixed bottom-0 inset-x-0 z-40 border-t border-white/10 bg-[#050915]/85 backdrop-blur-2xl shadow-[0_-18px_50px_rgba(0,0,0,0.6)] md:hidden"
      aria-label="Navegação principal"
    >
      <div className="mx-auto flex max-w-lg items-center justify-between px-6 py-3 text-[11px] text-white/75">
        {[
          {
            id: "explore",
            label: "Explorar",
            path: "/explorar",
            icon: "🧭",
            active: pathname === "/explorar" && !isSearchOpen,
            onClick: () => {
              onCloseSearch();
              router.push("/explorar");
            },
          },
          {
            id: "search",
            label: "Procurar",
            path: "/explorar?focus=search",
            icon: "🔍",
            active: isSearchOpen,
            onClick: () => {
              onOpenSearch();
            },
          },
          {
            id: "home",
            label: "Início",
            path: "/",
            icon: "🏠",
            spotlight: true,
            active: pathname === "/",
            onClick: () => {
              onCloseSearch();
              router.push("/");
            },
          },
          {
            id: "tickets",
            label: "Bilhetes",
            path: "/me/tickets",
            icon: "🎟️",
            active: pathname.startsWith("/me/tickets"),
            onClick: () => {
              onCloseSearch();
              router.push("/me/tickets");
            },
          },
          {
            id: "profile",
            label: "Perfil",
            path: "/me",
            icon: "🙍",
            active: pathname.startsWith("/me") && !pathname.startsWith("/me/tickets"),
            onClick: () => {
              onCloseSearch();
              router.push("/me");
            },
          },
        ].map((item) => {
          const active = item.active;

          if (item.spotlight) {
            return (
              <button
                key={item.id}
                type="button"
                onClick={item.onClick}
                className="relative flex flex-col items-center justify-center gap-1"
                aria-label={item.label}
              >
                <span className="absolute inset-0 translate-y-[-6px] blur-2xl rounded-full bg-[radial-gradient(circle_at_center,_rgba(107,255,255,0.35),_transparent_55%)]" />
                <span
                  className={`relative flex h-14 w-14 items-center justify-center rounded-full border ${
                    active
                      ? "border-[#6BFFFF]/80 bg-gradient-to-br from-[#FF00C8] via-[#6BFFFF] to-[#1646F5] shadow-[0_0_28px_rgba(107,255,255,0.7)]"
                      : "border-white/20 bg-gradient-to-br from-[#0a0f1c] via-[#0f172a] to-[#0a0f1c] shadow-[0_0_14px_rgba(0,0,0,0.5)]"
                  } text-xl text-black font-semibold`}
                >
                  {item.icon}
                </span>
                <span className="text-[10px] text-white/80 mt-0.5">{item.label}</span>
              </button>
            );
          }

          return (
            <button
              key={item.id}
              type="button"
              onClick={item.onClick}
              className={`flex flex-col items-center gap-1 rounded-xl px-3 py-1 transition ${
                active
                  ? "text-white bg-white/10 border border-white/15 shadow-[0_0_14px_rgba(107,255,255,0.35)]"
                  : "text-white/70 hover:text-white hover:bg-white/5"
              }`}
              aria-label={item.label}
            >
              <span className="text-lg leading-none">{item.icon}</span>
              <span className="text-[10px]">{item.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
