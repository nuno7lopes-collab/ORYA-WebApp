-- Novos campos de configuração e branding para organizers
ALTER TABLE "app_v3"."organizers"
  ADD COLUMN IF NOT EXISTS language text DEFAULT 'pt',
  ADD COLUMN IF NOT EXISTS public_listing_enabled boolean DEFAULT true,
  ADD COLUMN IF NOT EXISTS alerts_email text NULL,
  ADD COLUMN IF NOT EXISTS alerts_sales_enabled boolean DEFAULT true,
  ADD COLUMN IF NOT EXISTS alerts_payout_enabled boolean DEFAULT false,
  ADD COLUMN IF NOT EXISTS branding_avatar_url text NULL,
  ADD COLUMN IF NOT EXISTS branding_primary_color text NULL,
  ADD COLUMN IF NOT EXISTS branding_secondary_color text NULL;

-- Enum EventTemplateType → adiciona PADEL mantendo compatibilidade
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_type t
    JOIN pg_namespace n ON n.oid = t.typnamespace
    WHERE n.nspname = 'app_v3' AND t.typname = 'EventTemplateType'
  ) THEN
    CREATE TYPE "app_v3"."EventTemplateType" AS ENUM ('PARTY','SPORT','PADEL','VOLUNTEERING','TALK','OTHER');
  ELSIF NOT EXISTS (
    SELECT 1
    FROM pg_enum e
    JOIN pg_type t ON e.enumtypid = t.oid
    JOIN pg_namespace n ON n.oid = t.typnamespace
    WHERE n.nspname = 'app_v3' AND t.typname = 'EventTemplateType' AND e.enumlabel = 'PADEL'
  ) THEN
    ALTER TYPE "app_v3"."EventTemplateType" ADD VALUE 'PADEL';
  END IF;
END$$;
